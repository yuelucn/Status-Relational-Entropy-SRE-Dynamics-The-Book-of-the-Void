# -*- coding: utf-8 -*-
"""可微离散算子微积分 (operator_calculus) 单元测试。

运行:
    python -m pytest test_operator_calculus.py -v

覆盖:
    1. 链复形: D1 @ D0 = 0
    2. 算子代数: 组合/交换子/幂/加减 的封闭性与代数恒等式 (反对称、Jacobi)
    3. DEC: d^2 = 0, delta = d^T, Delta = d delta + delta d, 块结构
    4. 高阶导出: ad_A^k(B)
    5. 函数演算: 恒等/平方/对易性/对 eigh 的精度/简并安全
    6. 可微性: autograd 梯度 vs 有限差分; 梯度流至边权; 简并参数梯度; 解处梯度为 0
    7. 可训练性: 端到端训练恢复边权
"""

import numpy as np
import torch
import pytest

from operator_calculus import (
    ChainComplex,
    OperatorCalculus,
    Operator,
    run_training_demo,
)

F64 = torch.float64


# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def cc():
    return ChainComplex.triangular_band(8)


@pytest.fixture
def calc(cc):
    return OperatorCalculus(cc)


def _rand_w(m, seed=0):
    torch.manual_seed(seed)
    return 0.5 + 1.5 * torch.rand(m, dtype=F64)


# ---------------------------------------------------------------------------
# 1. 链复形
# ---------------------------------------------------------------------------
class TestChainComplex:
    def test_dims(self, cc):
        assert cc.dims() == (8, 16, 8)
        assert cc.N == 32

    def test_boundary_of_boundary_is_zero(self, cc):
        z = cc.D1 @ cc.D0
        assert float(torch.linalg.matrix_norm(z, ord="fro")) < 1e-12

    def test_edges_and_faces(self, cc):
        assert len(cc.edge_index) == 16
        assert len(cc.faces) == 8

    def test_requires_n_ge_4(self):
        with pytest.raises(ValueError):
            ChainComplex.triangular_band(3)


# ---------------------------------------------------------------------------
# 2. 算子代数 (封闭性 + 恒等式)
# ---------------------------------------------------------------------------
class TestOperatorAlgebra:
    def test_compose_stays_operator(self, calc):
        d, delta = calc.d(), calc.delta()
        assert isinstance(d @ delta, Operator)
        assert (d @ delta).shape == (calc.N, calc.N)

    def test_commutator_self_is_zero(self, calc):
        A = calc.hodge()
        C = A.commutator(A)
        assert float(torch.linalg.matrix_norm(C.M, ord="fro")) < 1e-10

    def test_commutator_antisymmetric(self, calc):
        A, B = calc.d(), calc.delta()
        lhs = A.commutator(B).M
        rhs = B.commutator(A).M
        assert float(torch.linalg.matrix_norm(lhs + rhs, ord="fro")) < 1e-12

    def test_jacobi_identity(self, calc):
        A, B, C = calc.d(), calc.delta(), calc.hodge()
        term = (A.commutator(B.commutator(C)).M
                + B.commutator(C.commutator(A)).M
                + C.commutator(A.commutator(B)).M)
        assert float(torch.linalg.matrix_norm(term, ord="fro")) < 1e-10

    def test_power_zero_is_identity(self, calc):
        A = calc.hodge()
        P0 = A.power(0)
        assert float(torch.linalg.matrix_norm(P0.M - torch.eye(calc.N, dtype=F64), ord="fro")) < 1e-12

    def test_power_two_matches_matmul(self, calc):
        A = calc.hodge()
        assert float(torch.linalg.matrix_norm(A.power(2).M - (A.M @ A.M), ord="fro")) < 1e-10

    def test_add_sub_scale(self, calc):
        A, B = calc.d(), calc.delta()
        expr = (A + B - B).M
        assert float(torch.linalg.matrix_norm(expr - A.M, ord="fro")) < 1e-12
        assert float(torch.linalg.matrix_norm(A.scale(3.0).M - 3.0 * A.M, ord="fro")) < 1e-12

    def test_power_negative_raises(self, calc):
        with pytest.raises(ValueError):
            calc.hodge().power(-1)


# ---------------------------------------------------------------------------
# 3. 离散外微分 (DEC)
# ---------------------------------------------------------------------------
class TestDEC:
    def test_d_squared_is_zero(self, calc):
        d = calc.d()
        assert float(torch.linalg.matrix_norm(d.M @ d.M, ord="fro")) < 1e-12

    def test_delta_is_d_transpose(self, calc):
        d, delta = calc.d(), calc.delta()
        assert float(torch.linalg.matrix_norm(delta.M - d.M.T, ord="fro")) < 1e-12

    def test_hodge_is_symmetric(self, calc):
        L = calc.hodge().M
        assert float(torch.linalg.matrix_norm(L - L.T, ord="fro")) < 1e-12

    def test_hodge_is_psd(self, calc):
        lam = torch.linalg.eigvalsh(calc.hodge().M)
        assert float(lam.min()) > -1e-10

    def test_hodge_identity(self, calc):
        """Delta == d delta + delta d"""
        d, delta = calc.d(), calc.delta()
        lhs = calc.hodge().M
        rhs = (d @ delta).M + (delta @ d).M
        assert float(torch.linalg.matrix_norm(lhs - rhs, ord="fro")) < 1e-10

    def test_hodge_block_structure(self, calc):
        L = calc.hodge().M
        D0, D1 = calc.C.D0, calc.C.D1
        n0, n1, n2 = calc.n0, calc.n1, calc.n2
        L0 = L[:n0, :n0]
        L1 = L[n0:n0 + n1, n0:n0 + n1]
        L2 = L[n0 + n1:, n0 + n1:]
        assert float(torch.linalg.matrix_norm(L0 - D0.T @ D0, ord="fro")) < 1e-12
        assert float(torch.linalg.matrix_norm(L1 - (D0 @ D0.T + D1.T @ D1), ord="fro")) < 1e-12
        assert float(torch.linalg.matrix_norm(L2 - D1 @ D1.T, ord="fro")) < 1e-12

    def test_laplacian0_is_hodge_c0_block(self, calc):
        w = _rand_w(calc.n1)
        L0 = calc.laplacian0(w).M
        L = calc.hodge(w).M[:calc.n0, :calc.n0]
        assert float(torch.linalg.matrix_norm(L0 - L, ord="fro")) < 1e-12


# ---------------------------------------------------------------------------
# 4. 高阶导出 (迭代交换子)
# ---------------------------------------------------------------------------
class TestHigherOrder:
    def test_ad_zero_is_B(self, calc):
        A, B = calc.d(), calc.delta()
        assert float(torch.linalg.matrix_norm(calc.ad(A, B, 0).M - B.M, ord="fro")) < 1e-12

    def test_ad_one_is_commutator(self, calc):
        A, B = calc.d(), calc.delta()
        assert float(torch.linalg.matrix_norm(calc.ad(A, B, 1).M - A.commutator(B).M, ord="fro")) < 1e-12

    def test_ad_two_matches_iteration(self, calc):
        A, B = calc.d(), calc.delta()
        manual = A.commutator(A.commutator(B)).M
        assert float(torch.linalg.matrix_norm(calc.ad(A, B, 2).M - manual, ord="fro")) < 1e-12

    def test_ad_negative_raises(self, calc):
        with pytest.raises(ValueError):
            calc.ad(calc.d(), calc.delta(), -1)


# ---------------------------------------------------------------------------
# 5. 函数演算 (Chebyshev, 可微)
# ---------------------------------------------------------------------------
class TestFunctionalCalculus:
    def test_returns_operator(self, calc):
        L = calc.laplacian0(_rand_w(calc.n1))
        assert isinstance(calc.functional(L, lambda t: t, K=16), Operator)

    def test_identity_function(self, calc):
        L = calc.laplacian0(_rand_w(calc.n1))
        approx = calc.functional(L, lambda t: t, K=24).M
        assert float(torch.linalg.matrix_norm(approx - L.M, ord="fro")) < 1e-6

    def test_square_function(self, calc):
        L = calc.laplacian0(_rand_w(calc.n1))
        approx = calc.functional(L, lambda t: t ** 2, K=24).M
        assert float(torch.linalg.matrix_norm(approx - L.M @ L.M, ord="fro")) < 1e-5

    def test_commutes_with_A(self, calc):
        L = calc.laplacian0(_rand_w(calc.n1))
        gL = calc.functional(L, lambda t: torch.exp(-0.4 * t), K=32).M
        assert float(torch.linalg.matrix_norm(gL @ L.M - L.M @ gL, ord="fro")) < 1e-8

    def test_matches_eigh(self, calc):
        L = calc.laplacian0(_rand_w(calc.n1))
        g = lambda t: torch.exp(-0.35 * t)
        b = float(torch.linalg.matrix_norm(L.M, ord=2).detach())
        approx = calc.functional(L, g, K=60, b=b).M
        lam, V = torch.linalg.eigh(L.M)
        exact = (V * g(lam)) @ V.T
        assert float(torch.linalg.matrix_norm(approx - exact, ord="fro")) < 1e-4

    def test_degenerate_safe(self, calc):
        """全同特征值 (c*I) 下函数演算仍精确 —— 这正是 eigh 会不稳的场景。"""
        g = lambda t: torch.exp(-0.4 * t)
        A = Operator(1.7 * torch.eye(8, dtype=F64), calc)
        approx = calc.functional(A, g, K=60, b=2.0).M
        exact = float(torch.exp(torch.tensor(-0.4 * 1.7))) * torch.eye(8, dtype=F64)
        assert float(torch.linalg.matrix_norm(approx - exact, ord="fro")) < 1e-6

    def test_unbound_operator_raises(self):
        A = Operator(torch.eye(4, dtype=F64))
        with pytest.raises(ValueError):
            A.functional(lambda t: t)


# ---------------------------------------------------------------------------
# 6. 可微性
# ---------------------------------------------------------------------------
class TestDifferentiability:
    def test_grad_matches_finite_difference(self, calc):
        """autograd 解析梯度 vs 中心差分 —— 可微性的核心证据。"""
        g = lambda t: torch.exp(-0.4 * t)
        w0 = _rand_w(calc.n1)
        b = float(torch.linalg.matrix_norm(calc.laplacian0(w0).M, ord=2).detach())

        def f(w):
            return torch.trace(calc.functional(calc.laplacian0(w), g, K=40, b=b).M)

        w = w0.clone().requires_grad_(True)
        f(w).backward()
        g_auto = w.grad.detach().clone()

        eps = 1e-6
        g_fd = torch.zeros_like(w0)
        with torch.no_grad():
            for i in range(calc.n1):
                wp = w0.clone(); wp[i] += eps
                wm = w0.clone(); wm[i] -= eps
                g_fd[i] = (f(wp) - f(wm)) / (2 * eps)

        np.testing.assert_allclose(g_auto.numpy(), g_fd.numpy(), rtol=1e-4, atol=1e-7)

    def test_grad_flows_to_weights(self, calc):
        g = lambda t: torch.exp(-0.4 * t)
        w = _rand_w(calc.n1).requires_grad_(True)
        loss = torch.sum(calc.functional(calc.laplacian0(w), g, K=24).M ** 2)
        loss.backward()
        assert w.grad is not None
        assert float(torch.linalg.vector_norm(w.grad)) > 0.0
        assert torch.isfinite(w.grad).all()

    def test_grad_degenerate_parameter(self, calc):
        """A(c) = c*I 全简并; d/dc tr g(A) = n * g'(c), 应精确。"""
        g = lambda t: torch.exp(-0.4 * t)
        c = torch.tensor(1.0, dtype=F64, requires_grad=True)

        def f(cc):
            A = Operator(cc * torch.eye(8, dtype=F64), calc)
            return torch.trace(calc.functional(A, g, K=60, b=2.0).M)

        f(c).backward()
        expected = 8.0 * (-0.4) * float(torch.exp(torch.tensor(-0.4)))
        np.testing.assert_allclose(float(c.grad), expected, rtol=1e-5)

    def test_grad_zero_at_solution(self, calc):
        """在真值 w* 处损失为 0, 梯度也应为 0 (可训练性的必要条件)。"""
        torch.manual_seed(1)
        g = lambda t: torch.exp(-0.4 * t)
        w_star = _rand_w(calc.n1, seed=2)
        X = torch.randn(calc.n0, 16, dtype=F64)
        target = (calc.functional(calc.laplacian0(w_star), g, K=32).M @ X).detach()

        w = w_star.clone().requires_grad_(True)
        pred = calc.functional(calc.laplacian0(w), g, K=32).M @ X
        loss = torch.mean((pred - target) ** 2)
        loss.backward()
        assert float(loss.detach()) < 1e-20
        assert float(torch.linalg.vector_norm(w.grad)) < 1e-10

    def test_jacobian_helper(self, calc):
        w = _rand_w(calc.n1).requires_grad_(True)
        J = calc.jacobian(lambda x: torch.sum(x ** 2), w)
        np.testing.assert_allclose(J.numpy(), (2 * w.detach()).numpy(), rtol=1e-10)


# ---------------------------------------------------------------------------
# 7. 可训练性
# ---------------------------------------------------------------------------
class TestTraining:
    def test_demo_recovers_weights(self):
        r = run_training_demo(seed=0, iters=400, P=16, verbose=False)
        assert r["loss1"] < r["loss0"] * 1e-6
        assert r["corr"] > 0.999
        assert r["mae"] < 1e-2

    def test_demo_underdetermined_single_probe(self):
        """单探针 (约束不足) 时损失仍可降为 0, 但权重不可辨识 —— 诚实记录该边界。"""
        r = run_training_demo(seed=0, iters=300, P=1, verbose=False)
        assert r["loss1"] < r["loss0"] * 1e-6
        # 欠定: 相关度不应接近 1
        assert r["corr"] < 0.9
