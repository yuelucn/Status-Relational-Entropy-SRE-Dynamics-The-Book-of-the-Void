#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E25 —— 用 SRE 骨架推导 alpha 的具体数值（SRE-alpha derivation, audited）

链条（每步标注 G=强制 / F=自由）:
  A1-A4 + R1 (4pi 闭合)                G   公理, 0 个连续参数
  DCF 复形 (8,12,5)                    G   Euler 1 = Mobius, beta_1 = 1
  指数 n = 60                          G*  按 Fork A（外部审查对 n 来源仍有争议）
  加权 Mobius 阶梯 M_60 的闭式谱        G   Laplacian, 0 参数
  alpha_0 = lambda_2 / lambda_max      G   零参数读数
  Z2 对合 P = S^30 的扇区劈            G   k 偶/奇 = 电子/光子
  跨片权 w = 1 + delta                 F   delta 是模量（A5），骨架不可导出
  alpha = lambda_2 / (lambda_max + 2delta)  G   给定 delta 之后
  => 自由连续参数 = 1 ; 目标 = 1 ; 独立信息 = 0

预登记判据:
  G1 闭式谱 vs 数值谱            <= 1e-12
  G2 零参数值复现 7.2974585e-3   |rel| <= 1e-12
  G3 奇支位移 = 2*delta, 偶支 = 0  |err| <= 1e-15 (相对)
  G4 lambda_2/(lambda_max+2d) 对 d 单调 -> 反解唯一
  G5 反解 delta 与 4.347e-5 一致到前 4 位
  G6 delta=0 的精确命中要求 n 非整数 -> 精确命中被禁止
  B1 比特审计: 自由参数 1, 目标 1 -> 0 比特
"""

import math

LOG = []


def P(fmt="", *args):
    s = fmt if not args else (fmt % args)
    print(s)
    LOG.append(s)


ALPHA_MEAS = 1.0 / 137.035999084
DELTA_DOC = 4.347e-5
N = 60


def lam(k, w, n=N):
    """M_n 的最小非零模/最大模闭式：2-2cos(2pi k/n) + 2w [k odd]"""
    return 2.0 - 2.0 * math.cos(2.0 * math.pi * k / n) + (2.0 * w if k % 2 else 0.0)


def pi1(n=N, w=1.0):
    return lam(2, w, n) / lam(n // 2 - 1, w, n)


P("=" * 78)
P("E25  alpha from the SRE skeleton  (free-parameter audit included)")
P("=" * 78)
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 0  The chain, with each step tagged G (forced) or F (free)")
P("=" * 78)
P("")
rows = [
    ("A1-A4 + R1 (4pi closure)", "axioms", "G", 0),
    ("DCF complex (8,12,5)", "8 nodes, 12 edges, beta_1=5", "G", 0),
    ("n = 60", "Fork A discretisation", "G*", 0),
    ("M_60 Laplacian closed form", "2-2cos(2pi k/60)+2w[k odd]", "G", 0),
    ("ring weight c", "cancels in the ratio", "G", 0),
    ("alpha_0 = lambda_2/lambda_max", "zero-parameter readout", "G", 0),
    ("Z2 involution P=S^30", "splits k even/odd", "G", 0),
    ("cross weight w = 1+delta", "modulus (A5, no-go N1)", "F", 1),
]
P("  %-34s %-28s %-4s %s" % ("step", "mechanism", "tag", "cont. params"))
for a, b, c, d in rows:
    P("  %-34s %-28s %-4s %d" % (a, b, c, d))
P("")
P("  (*) n=60 is forced inside Fork A; the earlier A_5 / Z_60 no-go shows it is")
P("      NOT forced by the graph data alone. That is a separate objection.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 1  Skeleton: DCF combinatorics (8 nodes, 12 edges, 5 cycles)")
P("=" * 78)
P("")
# edge-vertex incidence D (12x8), cycle-edge C (5x12) -- as in code/Maxwell.py
D_edge = [
    [1, -1, 0, 0, 0, 0, 0, 0], [0, 1, -1, 0, 0, 0, 0, 0],
    [0, 0, 1, -1, 0, 0, 0, 0], [0, 0, 0, 1, -1, 0, 0, 0],
    [0, 0, 0, 0, 1, -1, 0, 0], [0, 0, 0, 0, 0, 1, -1, 0],
    [0, 0, 0, 0, 0, 0, 1, -1], [-1, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, -1, 0, 0, 0, 0, 0], [0, 1, 0, -1, 0, 0, 0, 0],
    [0, 0, 1, 0, -1, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0, -1],
]
C_cycle = [
    [1, 1, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0],
    [0, 1, 1, 0, 0, -1, 0, 0, 1, 0, 0, 0],
    [0, 0, 1, 1, 0, 0, -1, 0, 0, 1, 0, 0],
    [1, 0, 0, 1, 0, 0, 0, -1, 0, 0, 1, 0],
    [0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, -1],
]
try:
    import numpy as np
except ImportError:
    P("  need numpy"); raise SystemExit(1)

D = np.array(D_edge, dtype=float)
C = np.array(C_cycle, dtype=float)
V, E, F = 8, 12, 5
rD = int(np.linalg.matrix_rank(D))
rC = int(np.linalg.matrix_rank(C))
CD = float(np.max(np.abs(C @ D)))
P("  V, E, F = %d, %d, %d ; V - E + F = %d" % (V, E, F, V - E + F))
P("  rank(D) = %d  -> beta_0 = %d (connected)" % (rD, V - rD))
P("  beta_1 (graph) = E - V + 1 = %d  = the '5' in (8,12,5,60)" % (E - V + 1))
P("  rank(C) = %d of 5 rows -> the 5 cycles are independent" % rC)
P("  max|C D| = %.1f  -> C is a cycle-basis matrix, NOT an oriented boundary" % CD)
P("")
P("  Correction to a common misreading: 8-12+5=1 is bookkeeping, not the Euler")
P("  characteristic of a cell complex (a graph has chi = V-E = -4). The '5' is")
P("  the cycle rank, and C D != 0 means the matrices in Maxwell.py do not form")
P("  a chain complex d^2 = 0. That does not affect anything below; the spectral")
P("  derivation uses only the graph M_60.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 2  Spectrum of M_60: closed form vs direct diagonalisation (G1)")
P("=" * 78)
P("")

def lap(n, w, c=1.0):
    L = np.zeros((n, n))
    for i in range(n):
        j = (i + 1) % n
        L[i, i] += c; L[j, j] += c; L[i, j] -= c; L[j, i] -= c
    for i in range(n // 2):
        j = i + n // 2
        L[i, i] += w; L[j, j] += w; L[i, j] -= w; L[j, i] -= w
    return L

ev = np.sort(np.linalg.eigvalsh(lap(N, 1.0)))
closed = np.sort([lam(k, 1.0) for k in range(N)])
g1 = float(np.max(np.abs(ev - closed)))
P("  max |numeric - closed| over all 60 modes = %.2e" % g1)
P("  G1 (<=1e-12): %s" % ("PASS" if g1 <= 1e-12 else "FAIL"))
P("")
P("  lambda_2  (k=2,  even/electron) = %.15f" % lam(2, 1.0))
P("  lambda_29 (k=29, odd/photon)    = %.15f" % lam(29, 1.0))
P("  (k=29 and k=31 are degenerate; lambda_max sits in the photon sector)")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 3  Zero-parameter value (G2)")
P("=" * 78)
P("")
a0 = pi1(N, 1.0)
g2 = abs(a0 / 0.007297458502472 - 1.0)
P("  alpha_0 = lambda_2/lambda_max = %.15e" % a0)
P("  1/alpha_0                     = %.9f" % (1.0 / a0))
P("  G2 (reproduces 7.2974585e-3): %s  (rel %.1e)" %
  ("PASS" if g2 <= 1e-12 else "FAIL", g2))
P("")
P("  measured  alpha = %.15e   (1/%.9f)" % (ALPHA_MEAS, 1.0 / ALPHA_MEAS))
dev = a0 / ALPHA_MEAS - 1.0
P("  zero-parameter deviation = %.3e  (%.1f ppm, alpha_0 HIGH)" % (dev, dev * 1e6))
P("")
P("  This is the one number SRE produces without any fitting:")
P("     alpha_SRE(0 free) = 1/%.5f   vs   1/%.5f" % (1.0 / a0, 1.0 / ALPHA_MEAS))
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 4  The Z2 fingerprint: which branch moves (G3)")
P("=" * 78)
P("")
evd = np.sort(np.linalg.eigvalsh(lap(N, 1.0 + DELTA_DOC)))
# 不能用"排序后逐元素相减"：退化会让配对错位。改按闭式逐模检验。
d_odd = [abs((lam(k, 1 + DELTA_DOC) - lam(k, 1.0)) - 2 * DELTA_DOC)
         for k in range(N) if k % 2 == 1]
d_even = [abs(lam(k, 1 + DELTA_DOC) - lam(k, 1.0))
          for k in range(N) if k % 2 == 0]
# 并确认数值谱在两个 w 下都等于各自的闭式（排除闭式自身错）
g1b = float(np.max(np.abs(evd - np.sort([lam(k, 1 + DELTA_DOC) for k in range(N)]))))
P("  closed-form shift, odd k  : max |shift - 2*delta| = %.2e  (2*delta = %.6e)"
  % (max(d_odd), 2 * DELTA_DOC))
P("  closed-form shift, even k : max |shift|           = %.2e" % max(d_even))
P("  numeric spectrum == closed form at w=1+delta      : %.2e" % g1b)
P("  G3 (odd = 2d, even = 0): %s" %
  ("PASS" if max(d_odd) <= 1e-12 and max(d_even) <= 1e-12 and g1b <= 1e-12 else "FAIL"))
P("  (a naive sorted-array difference gives 8.7e-5 on 'even' indices; that is")
P("   reindexing under degeneracy, not a physical shift.)")
P("")
P("  => the correction is not 'noise on the whole spectrum'. It is exactly one")
P("     number, deposited only in the k-odd (photon) branch. lambda_2 is in the")
P("     k-even branch and moves by nothing.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 5  Solve the one free number (G4, G5)")
P("=" * 78)
P("")
P("  exact relation:  alpha = lambda_2 / (lambda_max + 2*delta)")
P("")

def f(d):
    return lam(2, 1.0) / (lam(29, 1.0) + 2 * d)

mono = all(f(x) < f(x - 1e-8) for x in [5e-5, 1e-4, 2e-4, 5e-4])
P("  G4 monotone decreasing in delta: %s strings" % ("PASS" if mono else "FAIL"))
dsolve = (lam(2, 1.0) / ALPHA_MEAS - lam(29, 1.0)) / 2.0
P("  delta solved from alpha = %.10e" % dsolve)
P("  delta quoted in paper    = %.10e" % DELTA_DOC)
P("  G5 (agree to 4 digits): %s" % ("PASS" if abs(dsolve / DELTA_DOC - 1) < 1e-3 else "FAIL"))
P("")
a_at = f(dsolve)
P("  alpha(delta_solved) = %.15e" % a_at)
P("  |alpha_pred - alpha_meas|/alpha = %.2e" % abs(a_at / ALPHA_MEAS - 1))
P("")
P("  WARNING (this is the whole point):")
P("  with the 4-digit delta quoted in the paper the formula already lands on")
P("  alpha to 1.5e-10; with delta solved to 8 digits it lands exactly (0).")
P("  A prediction must miss at the scale of its inputs (1e-9 or worse).")
P("  Residual far BELOW input precision = the parameter was back-solved.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 6  Bit audit and the exact-hit prohibition (B1, G6)")
P("=" * 78)
P("")
P("  free continuous parameters : 1  (delta)")
P("  targets                    : 1  (alpha)")
P("  independent information    : 0 bit")
P("  reduce to the project's existing verdict: this is E18/E22's 0-bit result,")
P("  now with a structural reason: an abelian (Z2) channel carries a modulus,")
P("  not a charge. A modulus cannot be fixed by any discrete input.")
P("")
# n required for exact hit at delta = 0
# 注意: 非整数 n 下必须用 λ_max = 4+2cos(2π/n)（k=n/2-1 处的连续延拓），
# 不能固定 k=29 —— 固定索引只在 n=60 时恰好是极大。
def pi1_cont(n):
    return (1 - math.cos(4 * math.pi / n)) / (2 + math.cos(2 * math.pi / n))

lo, hi = 59.9, 60.2
for _ in range(300):
    mid = (lo + hi) / 2
    if pi1_cont(mid) > ALPHA_MEAS:
        lo = mid
    else:
        hi = mid
nstar = (lo + hi) / 2
P("  If delta were forced to 0, the exact hit needs n = %.9f (non-integer)." % nstar)
P("  G6: %s" % ("PASS (exact hit is forbidden)" if abs(nstar - 60) > 1e-4 else "FAIL"))
P("  => the 1.45e-5 residual is not 'not fine enough'. It is the amount the")
P("     modulus MUST absorb. Any graph derivation claiming alpha = lambda_2/lambda_max")
P("     exactly is therefore wrong in principle.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("PART 7  n-scan: would a different graph do better? (look-elsewhere)")
P("=" * 78)
P("")
hits = []
for n in range(8, 121, 2):
    v = pi1(n, 1.0)
    r = v / ALPHA_MEAS - 1.0
    if abs(r) < 1e-3:
        hits.append((n, r))
P("  even n in [8,120] (57 graphs): those within 1e-3 of alpha")
for n, r in hits:
    P("     n=%-4d rel = %+.3e" % (n, r))
P("  count = %d" % len(hits))
P("")
P("  Because delta is free and unobservable, 'tune n' and 'tune delta' are")
P("  degenerate: for any n there is a delta that hits alpha. So the n=60 hit")
P("  is not evidence for n=60; it is evidence that the correction exists.")
P("")

# ------------------------------------------------------------------
P("=" * 78)
P("VERDICT")
P("=" * 78)
P("  ZERO-PARAMETER  alpha = 1/%.6f   (%.1f ppm high)" % (1.0 / a0, dev * 1e6))
P("  WITH MODULUS    alpha = 1/%.6f   (matches by construction)" % (1.0 / a_at))
P("  the specific number you can quote from SRE alone is the first one.")
P("  the second one is exact only because delta = %.6e was read off alpha." % dsolve)
P("")
P("  What SRE genuinely derives: the FORM of the correction (relative, factor 2,")
P("  photon branch only, sign negative, scale 1/lambda_max) and the prohibition")
P("  of an exact graph hit. What it cannot derive: the magnitude of delta.")
P("=" * 78)
