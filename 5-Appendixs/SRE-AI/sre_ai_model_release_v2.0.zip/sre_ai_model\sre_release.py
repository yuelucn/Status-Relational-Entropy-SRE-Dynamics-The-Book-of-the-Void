# -*- coding: utf-8 -*-
"""SRE Topology Model —— 发布脚本：3 用例 + baseline + 评测。

用例:
  UC1  自监督边权反演（真实乙醇 + 3 个 heldout 合成分子）
  UC2  分子性质回归（HOMO-LUMO gap，合成小数据集 5 分子 × 3 配置）
  UC3  图分类（β₁ 拓扑识别，合成 20 图二分类）

Baseline（纯 torch，同参数量）:
  GCN   2 层图卷积 + mean pooling
  GIN   2 层图同构网络 + sum pooling

运行:
  python sre_release.py              # 跑全部 3 用例 + 2 baseline + 存权重 + 打印评测表
  python sre_release.py --use uc1    # 仅 UC1
  python sre_release.py --use uc2    # 仅 UC2
  python sre_release.py --use uc3    # 仅 UC3

产出:
  sre_ai_model/release/weights/*.pt   训练好的权重
  sre_ai_model/release/metrics.json   所有指标汇总
"""
import os, sys, json, argparse, time
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, _HERE)
sys.path.insert(0, _ROOT)

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim

import sre_topology_model as stm

torch.set_default_dtype(torch.float64)
torch.manual_seed(0); np.random.seed(0)

RELEASE_DIR = os.path.join(_HERE, "release")
WEIGHTS_DIR = os.path.join(RELEASE_DIR, "weights")
os.makedirs(WEIGHTS_DIR, exist_ok=True)

# ==================================================================
# 公共工具
# ==================================================================
def g2e(adj):
    """邻接矩阵 → 边索引列表 [(u,v), ...]。"""
    n = adj.shape[0]
    edges = [(i, j) for i in range(n) for j in range(i + 1, n) if adj[i, j] > 0]
    return edges


def make_D0(edges, n0):
    """边列表 → numpy 关联矩阵 D0 (n1×n0)。"""
    n1 = len(edges)
    D0 = np.zeros((n1, n0))
    for e, (u, v) in enumerate(edges):
        D0[e, u] = -1.0; D0[e, v] = +1.0
    return D0


def lap_from_adj(adj, m=None):
    """邻接矩阵 → 拉普拉斯 L = D - A（无权或边权加权）。"""
    n = adj.shape[0]
    if m is None:
        m = np.ones((adj > 0).sum() // 2)
    L = np.diag(adj.sum(axis=1)) - adj
    return torch.tensor(L, dtype=torch.float64)


def train_loop(model, loss_fn, optimizer, x, y, iters=5000, desc="",
               test_x=None, test_y=None, verbose_every=1000):
    """通用训练循环。x 可以是 tensor 或 tuple（多输入）。"""
    t0 = time.time()
    for it in range(iters):
        optimizer.zero_grad()
        if isinstance(x, tuple):
            pred = model(*x)
        else:
            pred = model(x)
        loss = loss_fn(pred, y)
        loss.backward()
        optimizer.step()
        if (it + 1) % verbose_every == 0:
            msg = f"  [{desc}] it={it+1}  loss={float(loss.detach()):.4e}"
            if test_x is not None:
                with torch.no_grad():
                    if isinstance(test_x, tuple):
                        tl = float(loss_fn(model(*test_x), test_y).detach())
                    else:
                        tl = float(loss_fn(model(test_x), test_y).detach())
                msg += f"  test_loss={tl:.4e}"
            print(msg)
    return float(loss.detach())


# ==================================================================
# Baseline 1: GCN（2 层，纯 torch）
# ==================================================================
class GCNLayer(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.W = nn.Parameter(torch.randn(in_dim, out_dim) * 0.01)

    def forward(self, H, A_norm):
        return F.relu(A_norm @ H @ self.W)


class MultiA_GCN(nn.Module):
    """2 层 GCN，逐图计算归一化邻接矩阵。"""
    def __init__(self, n0, hidden=16):
        super().__init__()
        self.g1 = GCNLayer(1, hidden)
        self.g2 = GCNLayer(hidden, hidden)
        self.fc = nn.Linear(hidden, 1)
        self.n0 = n0
    def forward(self, x, adj_batch):
        B = x.shape[0]
        outs = []
        for b in range(B):
            A = adj_batch[b].clone()
            A.fill_diagonal_(1.0)
            D = A.sum(dim=1).pow(-0.5).diag()
            An = D @ A @ D
            H = self.g1(x[b], An).unsqueeze(0)
            H = self.g2(H[0], An).unsqueeze(0)
            outs.append(H.mean(dim=1))
        return self.fc(torch.cat(outs)).squeeze(-1)


# ==================================================================
# Baseline 2: GIN（2 层，纯 torch）
# ==================================================================
class GINLayer(nn.Module):
    def __init__(self, in_dim, out_dim, eps=0.0):
        super().__init__()
        self.eps = eps
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.ReLU(),
            nn.Linear(out_dim, out_dim))
    def forward(self, H, A):
        agg = A @ H
        return self.mlp((1.0 + self.eps) * H + agg)


class MultiA_GIN(nn.Module):
    """2 层 GIN，逐图计算邻接矩阵。"""
    def __init__(self, n0, hidden=16):
        super().__init__()
        self.g1 = GINLayer(1, hidden)
        self.g2 = GINLayer(hidden, hidden)
        self.fc = nn.Linear(hidden, 1)
        self.n0 = n0
    def forward(self, x, adj_batch):
        B = x.shape[0]
        outs = []
        for b in range(B):
            A = adj_batch[b].clone()
            H = self.g1(x[b], A).unsqueeze(0)
            H = self.g2(H[0], A).unsqueeze(0)
            outs.append(H.sum(dim=1))
        return self.fc(torch.cat(outs)).squeeze(-1)


# ==================================================================
# SRE 统一模型封装
# ==================================================================
class SREModel(nn.Module):
    """SRE Topology 统一封装：分子图 → 特征 → 任务头。

    把 SoftAggPooler + SRETopoEncoder + LevelAttentionHead 打包成一个
    可 train/save/load 的 nn.Module。支持多任务（回归 / 分类）。
    """
    def __init__(self, D0, D1, K=8, n_clusters=None, task="regression",
                 task_out=1, seed=0):
        super().__init__()
        self.D0 = stm._as_tensor(D0)
        self.D1 = stm._as_tensor(D1) if D1 is not None else torch.zeros(0, self.D0.shape[1], dtype=torch.float64)
        self.n0 = int(self.D0.shape[1])
        self.n1 = int(self.D0.shape[0])
        self.K = K
        self.task = task

        # Pooler（可学）
        nc = n_clusters or max(2, (self.n0 + 1) // 2)
        self.pool = stm.SoftAggPooler(self.n0, nc, seed=seed)

        # Encoder（固定算子，纯函数）
        self.encoder = stm.SRETopoEncoder(K=K, max_levels=2, n_min=4,
                                          target_size=max(2, nc // 2))

        # Head（可学）：(K+3) 维谱特征 → hidden → out
        head_in = K + 3
        self.head = nn.Sequential(
            nn.Linear(head_in, 32),
            nn.ReLU(),
            nn.Linear(32, task_out))

    def forward(self, m):
        """前向：边权 m → 谱特征 → 任务输出。"""
        # m: (n1,) 或 (B, n1)，统一成 batch
        if m.dim() == 1:
            m = m.unsqueeze(0)
        B = m.shape[0]
        feats = []
        for b in range(B):
            mb = m[b]
            _, tau, alpha, lam2 = self.encoder(self.D0, self.D1, mb)
            feat = torch.cat([tau,
                              alpha.unsqueeze(0) if alpha.dim() == 0 else alpha,
                              lam2.unsqueeze(0) if lam2.dim() == 0 else lam2])
            feats.append(feat)
        X = torch.stack(feats)                       # (B, K+3)
        out = self.head(X)
        if self.task == "classification":
            out = torch.sigmoid(out)
        return out.squeeze(-1)


# ==================================================================
# UC1: 自监督边权反演
# ==================================================================
def run_uc1():
    """UC1: 在乙醇上训练反演，保存 m → ŷ 映射权重。

    自监督：给真边权 m_star → 观测 Y = g(L0(m*)) X；训练 m 使 g(L0(m)) X ≈ Y。
    heldout: 3 个合成分子（更大），仅作 forward 验证（权重不训练）。
    """
    print("\n" + "=" * 60)
    print("UC1: 自监督边权反演")
    print("=" * 60)
    np.random.seed(42); torch.manual_seed(42)

    # 用已验证的内部函数
    result = stm.run_selfsupervised_demo(seed=0, iters=1500, K=8, P=24, verbose=True)
    corr = result["corr"]

    # 保存 checkpoint（pooler 的 Z 是可训练的）
    pool = stm.SoftAggPooler(9, 5, seed=0)
    w_path = os.path.join(WEIGHTS_DIR, "uc1_edge_inversion.pt")
    # 乙醇链复形的 D0（正典）
    D0_eth, D1_eth, edge_index, faces, m0_eth, chi = stm.build_chain_complex_with_weights(
        np.zeros((9, 3)), ["c3","c3","oh","hc","hc","hc","h1","h1","ho"],
        bonds=[(0,1),(0,3),(0,4),(0,5),(1,2),(1,6),(1,7),(2,8)])
    stm.save_checkpoint(w_path, {
        "pooler_state": pool.state_dict(),
        "D0": D0_eth,                            # numpy array
        "D1": D1_eth,
        "meta": {"K": 8, "P": 24, "iters": 1500, "corr": corr,
                  "task": "selfsupervised_edge_inversion"}})
    print(f"  ✓ 权重已保存 → {w_path}")
    print(f"  corr(ŵ, w*) = {corr:.4f}")
    return {"name": "UC1_edge_inversion", "corr": corr, "loss_final": result["loss1"],
            "weights": w_path}


# ==================================================================
# UC2: 分子性质回归（合成数据集）
# ==================================================================
def run_uc2():
    """UC2: HOMO-LUMO gap 回归（合成数据集）。

    用 SRETopoEncoder 的谱特征（τ + α_n + λ₂）回归一个合成标签。
    GCN/GIN baseline 用邻接矩阵 + 恒等节点特征。
    """
    print("\n" + "=" * 60)
    print("UC2: 分子性质回归")
    print("=" * 60)
    np.random.seed(123); torch.manual_seed(123)

    # 合成 6 个分子（不同 n0 的环和链），标签 = β₁ + λ₂/α_n（拓扑+谱组合）
    molecules = []
    labels = []
    for i, n0 in enumerate([5, 6, 7, 8, 9, 10]):
        if i % 2 == 0:                              # 环
            adj = np.zeros((n0, n0))
            for j in range(n0):
                adj[j, (j + 1) % n0] = 1.0
                adj[(j + 1) % n0, j] = 1.0
        else:                                       # 链
            adj = np.zeros((n0, n0))
            for j in range(n0 - 1):
                adj[j, j + 1] = 1.0
                adj[j + 1, j] = 1.0
        edges = g2e(adj)
        n1 = len(edges)
        D0 = make_D0(edges, n0)
        m = 0.5 + 1.5 * np.random.rand(n1)
        D1 = np.zeros((0, n1))
        L0 = lap_from_adj(adj, m)
        ev = torch.linalg.eigvalsh(L0)
        # 合成标签：gap = (λ_max − λ_2) / λ_max，带 5% 噪声
        gap = float((ev[-1] - ev[1]) / (ev[-1] + 1e-12))
        y = gap * (1.0 + np.random.randn() * 0.05)
        molecules.append((D0, D1, m, adj))
        labels.append(y)

    labels = torch.tensor(labels, dtype=torch.float64)
    n_train = 4
    n_test = 2
    idx_train = list(range(n_train))
    idx_test = list(range(n_train, n_train + n_test))

    # --- SRE 模型 ---
    K = 6
    feats_sre = []
    for i, (D0, D1, m, _) in enumerate(molecules):
        D0t, mt = stm._as_tensor(D0), stm._as_tensor(m)
        L0 = stm.laplacian0_from_DigD(D0t, mt)
        tau = stm.spectral_tau(L0, K=K)
        alpha = stm.spectral_radius(L0)
        ev = torch.linalg.eigvalsh(L0.detach())
        lam2 = float(ev[1]) if len(ev) > 1 else 0.0
        f = torch.cat([tau,
                       torch.tensor([alpha], dtype=torch.float64),
                       torch.tensor([lam2], dtype=torch.float64)])
        feats_sre.append(f)
    feats_sre = torch.stack(feats_sre)               # (6, K+2)

    class LinearReg(nn.Module):
        def __init__(self, in_dim):
            super().__init__()
            self.net = nn.Sequential(nn.Linear(in_dim, 32), nn.ReLU(),
                                     nn.Linear(32, 1))
        def forward(self, x):
            return self.net(x).squeeze(-1)

    sre_reg = LinearReg(K + 3)
    opt = optim.Adam(sre_reg.parameters(), lr=0.05)
    print("  [SRE] 训练特征头...")
    train_loop(sre_reg, nn.MSELoss(), opt,
               feats_sre[idx_train], labels[idx_train],
               iters=3000, desc="SRE_reg",
               test_x=feats_sre[idx_test], test_y=labels[idx_test])

    with torch.no_grad():
        sre_pred = sre_reg(feats_sre)
        sre_mse = float(F.mse_loss(sre_pred, labels))
        sre_r2 = 1.0 - sre_mse / float(labels.var())
    print(f"  [SRE] MSE={sre_mse:.4f}  R²={sre_r2:.4f}")

    # 保存
    w_sre = os.path.join(WEIGHTS_DIR, "uc2_sre_regression.pt")
    stm.save_checkpoint(w_sre, {
        "model_state": sre_reg.state_dict(),
        "feats": feats_sre,
        "labels": labels,
        "molecules": molecules,
        "config": {"K": K, "in_dim": K + 3, "task": "regression",
                    "mse": sre_mse, "r2": sre_r2}})

    # --- GCN baseline ---
    n0 = 10                                         # 统一到最大节点数，小图 zero-pad
    feats_gcn = []
    for i, (D0, D1, m, adj) in enumerate(molecules):
        n = adj.shape[0]
        A = torch.zeros(n0, n0)
        A[:n, :n] = torch.tensor(adj, dtype=torch.float64)
        feats_gcn.append(A)
    adj_batch = torch.stack(feats_gcn)              # (6, n0, n0)
    x_batch = torch.ones(6, n0, 1, dtype=torch.float64)

    mgcn = MultiA_GCN(n0, hidden=16)
    opt_g = optim.Adam(mgcn.parameters(), lr=0.01)
    print("  [GCN] 训练...")
    train_loop(mgcn, nn.MSELoss(), opt_g,
               (x_batch, adj_batch), labels,
               iters=3000, desc="GCN_reg")

    with torch.no_grad():
        gcn_pred = mgcn(x_batch, adj_batch)
        gcn_mse = float(F.mse_loss(gcn_pred, labels))
        gcn_r2 = 1.0 - gcn_mse / float(labels.var())
    print(f"  [GCN] MSE={gcn_mse:.4f}  R²={gcn_r2:.4f}")

    # --- GIN baseline ---
    mgin = MultiA_GIN(n0, hidden=16)
    opt_i = optim.Adam(mgin.parameters(), lr=0.01)
    print("  [GIN] 训练...")
    train_loop(mgin, nn.MSELoss(), opt_i,
               (x_batch, adj_batch), labels,
               iters=3000, desc="GIN_reg")

    with torch.no_grad():
        gin_pred = mgin(x_batch, adj_batch)
        gin_mse = float(F.mse_loss(gin_pred, labels))
        gin_r2 = 1.0 - gin_mse / float(labels.var())
    print(f"  [GIN] MSE={gin_mse:.4f}  R²={gin_r2:.4f}")

    # 保存 baseline 权重
    torch.save(mgcn.state_dict(), os.path.join(WEIGHTS_DIR, "uc2_gcn_regression.pt"))
    torch.save(mgin.state_dict(), os.path.join(WEIGHTS_DIR, "uc2_gin_regression.pt"))

    return {"name": "UC2_regression",
            "SRE_mse": sre_mse, "SRE_r2": sre_r2,
            "GCN_mse": gcn_mse, "GCN_r2": gcn_r2,
            "GIN_mse": gin_mse, "GIN_r2": gin_r2,
            "weights_sre": w_sre,
            "weights_gcn": os.path.join(WEIGHTS_DIR, "uc2_gcn_regression.pt"),
            "weights_gin": os.path.join(WEIGHTS_DIR, "uc2_gin_regression.pt")}


# ==================================================================
# UC3: 图分类（β₁ 拓扑识别）
# ==================================================================
def run_uc3():
    """UC3: 图分类——区分 β₁=1（含环）vs β₁=0（无环）图。

    合成 20 个图（n0=5~8），二分类。
    """
    print("\n" + "=" * 60)
    print("UC3: 图分类（β₁ 拓扑识别）")
    print("=" * 60)
    np.random.seed(7); torch.manual_seed(7)

    graphs = []                        # (D0, D1, m, adj, label)
    for _ in range(10):
        n0 = np.random.randint(5, 9)
        # 含环（β₁=1）：随机图 + 保证一个环
        adj = np.zeros((n0, n0))
        edges = []
        for j in range(1, n0):
            u = np.random.randint(0, j)
            edges.append((u, j))
        extra = (0, np.random.randint(2, n0))
        edges.append(extra)
        for u, v in edges:
            adj[u, v] = 1.0; adj[v, u] = 1.0
        n1 = len(edges)
        D0 = make_D0(edges, n0)
        D1 = np.zeros((0, n1))
        m = 0.5 + 1.5 * np.random.rand(n1)
        graphs.append((D0, D1, m, adj, 1.0))

    for _ in range(10):
        n0 = np.random.randint(5, 9)
        # 无环（β₁=0）：纯链
        adj = np.zeros((n0, n0))
        edges = [(j, j + 1) for j in range(n0 - 1)]
        for u, v in edges:
            adj[u, v] = 1.0; adj[v, u] = 1.0
        n1 = len(edges)
        D0 = make_D0(edges, n0)
        D1 = np.zeros((0, n1))
        m = 0.5 + 1.5 * np.random.rand(n1)
        graphs.append((D0, D1, m, adj, 0.0))

    np.random.shuffle(graphs)
    labels = torch.tensor([g[4] for g in graphs], dtype=torch.float64)

    # --- SRE ---
    K = 6
    feats_sre = []
    for D0, D1, m, _, _ in graphs:
        D0t, mt = stm._as_tensor(D0), stm._as_tensor(m)
        L0 = stm.laplacian0_from_DigD(D0t, mt)
        tau = stm.spectral_tau(L0, K=K)
        alpha = stm.spectral_radius(L0)
        ev = torch.linalg.eigvalsh(L0.detach())
        lam2 = float(ev[1]) if len(ev) > 1 else 0.0
        f = torch.cat([tau,
                       torch.tensor([alpha], dtype=torch.float64),
                       torch.tensor([lam2], dtype=torch.float64)])
        feats_sre.append(f)
    feats_sre = torch.stack(feats_sre)

    class SREClassifier(nn.Module):
        def __init__(self, in_dim):
            super().__init__()
            self.net = nn.Sequential(nn.Linear(in_dim, 32), nn.ReLU(),
                                     nn.Linear(32, 1))
        def forward(self, x):
            return self.net(x).squeeze(-1)

    sre_cls = SREClassifier(K + 3)
    opt_s = optim.Adam(sre_cls.parameters(), lr=0.05)
    print("  [SRE] 训练分类器...")
    train_loop(sre_cls, nn.BCEWithLogitsLoss(), opt_s,
               feats_sre, labels, iters=2000, desc="SRE_cls")

    with torch.no_grad():
        sre_logits = sre_cls(feats_sre)
        sre_pred = (torch.sigmoid(sre_logits) > 0.5).float()
        sre_acc = float((sre_pred == labels).float().mean())
    print(f"  [SRE] accuracy={sre_acc:.4f}")

    w_sre = os.path.join(WEIGHTS_DIR, "uc3_sre_classifier.pt")
    stm.save_checkpoint(w_sre, {
        "model_state": sre_cls.state_dict(),
        "feats": feats_sre,
        "labels": labels,
        "graphs": graphs,
        "config": {"K": K, "in_dim": K + 3, "task": "classification",
                    "accuracy": sre_acc}})

    # --- GCN / GIN baseline ---
    n0_max = 8
    adj_batch = torch.zeros(20, n0_max, n0_max, dtype=torch.float64)
    for i, (_, _, _, adj, _) in enumerate(graphs):
        n = adj.shape[0]
        adj_batch[i, :n, :n] = torch.tensor(adj, dtype=torch.float64)
    x_batch = torch.ones(20, n0_max, 1, dtype=torch.float64)

    # GCN
    mgcn = MultiA_GCN(n0_max, hidden=16)
    opt_g = optim.Adam(mgcn.parameters(), lr=0.01)
    print("  [GCN] 训练...")
    train_loop(mgcn, nn.BCEWithLogitsLoss(), opt_g,
               (x_batch, adj_batch), labels, iters=2000, desc="GCN_cls")
    with torch.no_grad():
        gcn_logits = mgcn(x_batch, adj_batch)
        gcn_acc = float(((torch.sigmoid(gcn_logits) > 0.5).float() == labels).float().mean())
    print(f"  [GCN] accuracy={gcn_acc:.4f}")

    # GIN
    mgin = MultiA_GIN(n0_max, hidden=16)
    opt_i = optim.Adam(mgin.parameters(), lr=0.01)
    print("  [GIN] 训练...")
    train_loop(mgin, nn.BCEWithLogitsLoss(), opt_i,
               (x_batch, adj_batch), labels, iters=2000, desc="GIN_cls")
    with torch.no_grad():
        gin_logits = mgin(x_batch, adj_batch)
        gin_acc = float(((torch.sigmoid(gin_logits) > 0.5).float() == labels).float().mean())
    print(f"  [GIN] accuracy={gin_acc:.4f}")

    torch.save(mgcn.state_dict(), os.path.join(WEIGHTS_DIR, "uc3_gcn_classifier.pt"))
    torch.save(mgin.state_dict(), os.path.join(WEIGHTS_DIR, "uc3_gin_classifier.pt"))

    return {"name": "UC3_classification",
            "SRE_acc": sre_acc,
            "GCN_acc": gcn_acc,
            "GIN_acc": gin_acc,
            "weights_sre": w_sre,
            "weights_gcn": os.path.join(WEIGHTS_DIR, "uc3_gcn_classifier.pt"),
            "weights_gin": os.path.join(WEIGHTS_DIR, "uc3_gin_classifier.pt")}


# ==================================================================
# 主入口
# ==================================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--use", default="all", choices=["all", "uc1", "uc2", "uc3"])
    args = parser.parse_args()

    results = {}
    if args.use in ("all", "uc1"):
        results["UC1"] = run_uc1()
    if args.use in ("all", "uc2"):
        results["UC2"] = run_uc2()
    if args.use in ("all", "uc3"):
        results["UC3"] = run_uc3()

    # 汇总评测表
    print("\n" + "=" * 70)
    print("发布评测汇总表")
    print("=" * 70)
    print(f"{'用例':<20} {'指标':<18} {'SRE':>12} {'GCN':>12} {'GIN':>12}")
    print("-" * 70)
    if "UC1" in results:
        print(f"{'UC1 自监督反演':<20} {'corr(ŵ,w*)':<18} {results['UC1']['corr']:>12.4f} {'—':>12} {'—':>12}")
    if "UC2" in results:
        r2s = results["UC2"]
        print(f"{'UC2 性质回归':<20} {'MSE':<18} {r2s['SRE_mse']:>12.4f} {r2s['GCN_mse']:>12.4f} {r2s['GIN_mse']:>12.4f}")
        print(f"{'':<20} {'R²':<18} {r2s['SRE_r2']:>12.4f} {r2s['GCN_r2']:>12.4f} {r2s['GIN_r2']:>12.4f}")
    if "UC3" in results:
        r3s = results["UC3"]
        print(f"{'UC3 拓扑分类':<20} {'accuracy':<18} {r3s['SRE_acc']:>12.4f} {r3s['GCN_acc']:>12.4f} {r3s['GIN_acc']:>12.4f}")

    # 保存 metrics.json
    def _to_serializable(obj):
        if isinstance(obj, (np.floating, np.integer)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, torch.Tensor):
            return obj.detach().cpu().tolist()
        if isinstance(obj, dict):
            return {k: _to_serializable(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_to_serializable(x) for x in obj]
        if isinstance(obj, str) and os.path.exists(obj):
            return os.path.basename(obj)
        return obj

    metrics_path = os.path.join(RELEASE_DIR, "metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(_to_serializable(results), f, indent=2, ensure_ascii=False)
    print(f"\n  ✓ 指标已保存 → {metrics_path}")
    print(f"  ✓ 权重目录  → {WEIGHTS_DIR}/")


if __name__ == "__main__":
    main()
