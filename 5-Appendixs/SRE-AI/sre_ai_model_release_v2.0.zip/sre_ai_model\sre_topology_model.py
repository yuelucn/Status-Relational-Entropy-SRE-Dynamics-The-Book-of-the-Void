# -*- coding: utf-8 -*-
"""SRE 可微拓扑模型层 (SRE Differentiable Topology Model Layer)

本模块是 SRE 19 算子正典之上的**新建模型层**（不改动正典），把链复形
``(D0, D1, m, X)`` 提升为一个**可微、可分层粗粒化**的 AI 模型骨架。

设计原则（见 .trae/documents/SRE_AI模型设计方案.md）
-----------------------------------------------------
- 正典 19 算子保持 numpy-only 冻结；本模块为 torch 侧新层，单独目录便于独立归档。
- Step 1（承重件）：粗粒化/池化算子 —— 精确模式（保 β₁）+ 可学模式（softmax 软分配）。
- Step 2：尺度规范固定 + 自监督反演 demo。
- Step 3：多颗粒度特征 + 层级注意力 + MLP 头 + 四类硬测试。

关键数学
--------
1) 链复形合法性：``D0' = D0 P``，``D1' = D1[:, keep]`` ⇒ ``D1' D0' = 0``。
2) Galerkin 恒等：``L0' = D0'ᵀ diag(m) D0' = Pᵀ L0 P``。
3) 精确模式保 β₁：仅收缩「自由边」（不出现在任何 2-面边界上的边），
   被收缩边的 ``D1`` 列恒为零列 ⇒ 删除后 ``rank(D1') = rank(D1)``，
   且 ``n1' = n1 − |T|``、``rank(D0') = C − β₀``（T 为无环配对），故
   ``β₁' = n1' − rank(D0') − rank(D1') = n1 − rank(D0) − rank(D1) = β₁``。
   实现中进一步对每个配对做「β 严格相等」校验，逐对接受，保证精确。
4) 谱形矩 τ_k = tr(T_k(Y))/N，``Y = 2 L0 / α_n − I``，三项递推、无 eigh、天然可微。

依赖：numpy（正典）+ torch（模型层）。
"""

from __future__ import annotations

import os
import sys

# --- Windows 兼容开关: numpy(MKL) 与 torch 各自链接 OpenMP 运行时,
#     同进程加载会报 libiomp5md.dll 重复初始化而中止; 官方建议设置
#     KMP_DUPLICATE_LIB_OK 允许继续执行。必须在 import numpy/torch 之前设置。---
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

# --- 模块内 sys.path bootstrap: 指向父目录以复用 19 算子正典 (numpy-only) ---
_HERE = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

import numpy as np  # noqa: E402
import torch  # noqa: E402
import torch.nn as nn  # noqa: E402
import torch.nn.functional as F  # noqa: E402

import operator_calculus as oc  # noqa: E402  复用可微算子演算(链复形/Chebyshev/Laplacian)
from sre_electronic_layer import SREElectronicOperatorSuite  # noqa: E402  复用分子→A_s
from sre_spectral_solver import SRESpectralSolverSuite  # noqa: E402  复用 laplacian/spectral_assets

torch.set_default_dtype(torch.float64)
_DTYPE = torch.float64
_ZERO_TOL = 1e-12
_SPECTRAL_EPS = 1e-12


# ---------------------------------------------------------------------------
# 0. 模块级显式输入校验
# ---------------------------------------------------------------------------
def _validate_environment():
    """模块级显式校验：确认 torch/numpy 与父项目正典模块均可导入且可用。

    参数: 无
    返回: 无（校验失败时抛出 RuntimeError）
    """
    if np is None or torch is None:  # pragma: no cover - 导入失败时更早报错
        raise RuntimeError("SRE 模型层需要 numpy 与 torch 同时可用")
    if oc is None or SREElectronicOperatorSuite is None or SRESpectralSolverSuite is None:
        raise RuntimeError("SRE 模型层要求父项目正典模块 operator_calculus / "
                           "sre_electronic_layer / sre_spectral_solver 可导入")
    if torch.get_default_dtype() != _DTYPE:  # pragma: no cover
        torch.set_default_dtype(_DTYPE)


_validate_environment()


# ---------------------------------------------------------------------------
# 1. 基础工具：张量/数组互转
# ---------------------------------------------------------------------------
def _as_numpy(x) -> np.ndarray:
    """统一转为 float64 numpy 数组。

    参数: x —— torch.Tensor 或 array-like
    返回: np.ndarray(float64)
    """
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().numpy().astype(np.float64)
    return np.asarray(x, dtype=np.float64)


def _as_tensor(x) -> torch.Tensor:
    """统一转为 float64 torch 张量。

    参数: x —— torch.Tensor 或 array-like
    返回: torch.Tensor(float64)
    """
    if isinstance(x, torch.Tensor):
        return x.to(_DTYPE)
    return torch.as_tensor(np.asarray(x, dtype=np.float64), dtype=_DTYPE)


# ---------------------------------------------------------------------------
# 2. Step 1 承重件：粗粒化 / 池化算子
# ---------------------------------------------------------------------------
def exact_beta(D0, D1):
    """精确计算链复形的 Betti 数（非可微，仅用于校验）。

    β₀ = n0 − rank(D0)，β₁ = n1 − rank(D0) − rank(D1)。

    参数:
        D0: array-like, (n1, n0) 有向关联矩阵（1-阶边界算子）
        D1: array-like, (n2, n1) 面-边边界算子（可为 (0, n1)）

    返回:
        (beta0, beta1): tuple[int, int]
    """
    D0n = _as_numpy(D0)
    if D0n.ndim != 2:
        raise ValueError(f"D0 必须为二维矩阵，当前形状: {D0n.shape}")
    n1, n0 = D0n.shape
    r0 = int(np.linalg.matrix_rank(D0n)) if D0n.size else 0
    D1n = _as_numpy(D1)
    if D1n.size:
        if D1n.ndim != 2 or D1n.shape[1] != n1:
            raise ValueError(f"D1 形状必须为 (n2, {n1})，当前: {D1n.shape}")
        r1 = int(np.linalg.matrix_rank(D1n))
    else:
        r1 = 0
    beta0 = n0 - r0
    beta1 = n1 - r0 - r1
    return beta0, beta1


def _cluster_P(n0: int, pairs) -> torch.Tensor:
    """由配对列表构造 0/1 聚合矩阵 P。

    参数:
        n0: int, 顶点数
        pairs: list[tuple[int,int]], 已接受的配对（每对合并为一个簇）
    返回:
        P: torch.Tensor, (n0, C) 0/1 聚合矩阵（列=簇，行=顶点）
    """
    return _clusters_to_P(n0, [[u, v] for u, v in pairs])


def _clusters_to_P(n0: int, clusters) -> torch.Tensor:
    """由簇列表（顶点列表）构造 0/1 聚合矩阵 P；未出现顶点各自成单点簇。

    参数:
        n0: int, 顶点数
        clusters: list[list[int]], 互不相交的簇
    返回:
        P: torch.Tensor, (n0, C) 0/1 聚合矩阵
    """
    cid = -np.ones(n0, dtype=int)
    c = 0
    for cl in clusters:
        for v in cl:
            cid[v] = c
        c += 1
    for v in range(n0):
        if cid[v] == -1:
            cid[v] = c
            c += 1
    P = torch.zeros(n0, c, dtype=_DTYPE)
    for v in range(n0):
        P[v, cid[v]] = 1.0
    return P


def _keep_mask(D0t: torch.Tensor, Pt: torch.Tensor) -> torch.Tensor:
    """聚合后边保留掩码：每簇内部仅丢弃其 BFS 生成树的 k−1 条树边，
    其余边（簇内非树边 → 自环、簇间边）全部保留。

    该规则使 ``n1' = n1 − (n0 − C)``，配合 ``rank(D0') = C − β₀`` 得
    ``β₁' = n1' − rank(D0') − rank(D1') = β₁``（当且仅当 ``rank(D1') = rank(D1)``）。

    参数:
        D0t: torch.Tensor, (n1, n0) 关联矩阵
        Pt:  torch.Tensor, (n0, C) 0/1 聚合矩阵
    返回:
        keep: torch.Tensor, (n1,) 布尔掩码，True 表示保留该边行
    """
    n1, n0 = int(D0t.shape[0]), int(D0t.shape[1])
    if Pt.shape[0] != n0:
        raise ValueError(f"P 行数应为 n0={n0}，当前: {tuple(Pt.shape)}")
    cid = _as_numpy(Pt).argmax(axis=1)                       # (n0,)
    supp = _as_numpy(D0t).__abs__() > _ZERO_TOL
    adj_e = [[] for _ in range(n0)]
    for e in range(n1):
        idx = np.nonzero(supp[e])[0]
        if idx.size == 2:
            a, b = int(idx[0]), int(idx[1])
            adj_e[a].append((b, e))
            adj_e[b].append((a, e))

    keep = np.ones(n1, dtype=bool)
    cluster_verts = {}
    for v in range(n0):
        cluster_verts.setdefault(int(cid[v]), []).append(v)
    for verts in cluster_verts.values():
        vs = set(verts)
        if len(vs) <= 1:
            continue
        visited = {verts[0]}
        queue = [verts[0]]
        while queue:
            u = queue.pop(0)
            for w, e in adj_e[u]:
                if w in vs and w not in visited:
                    visited.add(w)
                    queue.append(w)
                    keep[e] = False                          # 丢弃簇内生成树边
    return torch.as_tensor(keep, dtype=torch.bool)


def _chunk_connected(adj, n0: int, target: int, descending: bool = False):
    """连通块生长：每块为连通子图且规模 ≤ target。

    按种子序（度数升序或降序）取未分配顶点起块，BFS 吸收未分配邻居直至块满；
    扩展时**优先吸收度数更小的邻居（叶优先）**，避免一个枢纽块吞掉相邻枢纽而
    使其叶邻居失去归属（星形图下可显著减少块数）。两种种子序取块数更小者。

    参数:
        adj: list[list[int]], 邻接表
        n0: int, 顶点数
        target: int, 目标块规模（≥2）
        descending: bool, True 时按度数降序取种子
    返回:
        clusters: list[list[int]], 连通块列表（覆盖全部顶点，互不相交）
    """
    deg = [len(a) for a in adj]
    order = sorted(range(n0), key=lambda v: deg[v], reverse=bool(descending))
    assigned = np.zeros(n0, dtype=bool)
    clusters = []
    for s in order:
        if assigned[s]:
            continue
        block = [s]
        assigned[s] = True
        queue = [s]
        while queue and len(block) < target:
            u = queue.pop(0)
            for w in sorted(adj[u], key=lambda x: deg[x]):
                if not assigned[w]:
                    assigned[w] = True
                    block.append(w)
                    queue.append(w)
                    if len(block) >= target:
                        break
        clusters.append(block)
    return clusters


def _partition_from_clusters(D0t, D1t, n0: int, clusters, beta_ref):
    """对候选连通块做逐块 β 校验，返回被接受的聚合矩阵 P。

    参数:
        D0t: torch.Tensor, (n1, n0) 关联矩阵
        D1t: torch.Tensor, (n2, n1) 面算子（可为 (0, n1)）
        n0: int, 顶点数
        clusters: list[list[int]], 候选连通块
        beta_ref: tuple[int,int], 原始 β₀/β₁ 参考值
    返回:
        P: torch.Tensor, (n0, C) 0/1 聚合矩阵
    """
    has_D1 = bool(D1t.numel())
    accepted = []
    for cl in clusters:
        Pt = _clusters_to_P(n0, accepted + [cl])
        keep = _keep_mask(D0t, Pt)
        D0_new = (D0t @ Pt)[keep]
        D1_new = D1t[:, keep] if has_D1 else torch.zeros(0, int(keep.sum()), dtype=_DTYPE)
        if exact_beta(D0_new, D1_new) == beta_ref:
            accepted = accepted + [cl]
    return _clusters_to_P(n0, accepted)


def tree_partition(D0, D1=None, target_size: int = 4) -> torch.Tensor:
    """精确模式（精确保 β₁）的连通块聚合矩阵 P。

    流程：由 D0 支撑建立无向图 → 取「叶优先 / 枢纽优先」两种连通块生长方案 →
    各自逐块做「β₀/β₁ 严格相等」校验 → 选块数(C)更小者作为聚合矩阵。

    参数:
        D0: array-like, (n1, n0) 有向关联矩阵
        D1: array-like 或 None, (n2, n1) 面算子；None 视为无 2-面
        target_size: int, 目标块规模（≥2，用于控制缩减倍率）
    返回:
        P: torch.Tensor, (n0, C) 0/1 聚合矩阵；C 为块数（C ≤ n0）
    """
    D0n = _as_numpy(D0)
    if D0n.ndim != 2:
        raise ValueError(f"D0 必须为二维矩阵，当前形状: {D0n.shape}")
    n1, n0 = D0n.shape
    if target_size < 2:
        raise ValueError(f"target_size 必须 ≥ 2，当前输入: {target_size}")
    if n0 < 2:
        return torch.eye(n0, dtype=_DTYPE)
    D1n = np.zeros((0, n1), dtype=np.float64) if D1 is None else _as_numpy(D1)
    if D1n.size and (D1n.ndim != 2 or D1n.shape[1] != n1):
        raise ValueError(f"D1 形状必须为 (n2, {n1})，当前: {D1n.shape}")

    # 无向邻接（自环跳过）
    supp = np.abs(D0n) > _ZERO_TOL
    adj = [[] for _ in range(n0)]
    for e in range(n1):
        idx = np.nonzero(supp[e])[0]
        if idx.size == 2:
            u, v = int(idx[0]), int(idx[1])
            adj[u].append(v)
            adj[v].append(u)

    beta_ref = exact_beta(D0n, D1n)
    D0t = torch.as_tensor(D0n, dtype=_DTYPE)
    D1t = torch.as_tensor(D1n, dtype=_DTYPE)

    best_P = None
    for descending in (False, True):
        clusters = _chunk_connected(adj, n0, target_size, descending=descending)
        P = _partition_from_clusters(D0t, D1t, n0, clusters, beta_ref)
        if best_P is None or P.shape[1] < best_P.shape[1]:
            best_P = P
    return best_P


def aggregate_complex(D0, D1, m, X, P):
    """按聚合矩阵 P 粗粒化链复形 (D0, D1, m, X)。

    ``D0' = D0 P``（仅保留非零行），``D1' = D1[:, keep]``，
    ``m' = m[keep]``，``X' = Pᵀ X``。满足 ``D1' D0' = 0`` 与 ``L0' = Pᵀ L0 P``。

    参数:
        D0: array-like, (n1, n0) 关联矩阵
        D1: array-like, (n2, n1) 面算子（可为 (0, n1)）
        m:  array-like, (n1,) 边权
        X:  array-like, (n0, d) 顶点特征
        P:  array-like, (n0, C) 聚合矩阵（0/1 或软分配）
    返回:
        (D0', D1', m', X')，类型均为 torch.Tensor(float64)
    """
    D0t = _as_tensor(D0)
    D1t = _as_tensor(D1)
    mt = _as_tensor(m).reshape(-1)
    Xt = _as_tensor(X)
    Pt = _as_tensor(P)
    if Pt.ndim != 2 or Pt.shape[0] != D0t.shape[1]:
        raise ValueError(f"P 形状应为 (n0={D0t.shape[1]}, C)，当前: {tuple(Pt.shape)}")
    if mt.shape[0] != D0t.shape[0]:
        raise ValueError(f"m 长度应为 n1={D0t.shape[0]}，当前: {tuple(mt.shape)}")
    if Xt.ndim != 2 or Xt.shape[0] != D0t.shape[1]:
        raise ValueError(f"X 形状应为 (n0={D0t.shape[1]}, d)，当前: {tuple(Xt.shape)}")

    D0p = D0t @ Pt                     # (n1, C)
    keep = _keep_mask(D0t, Pt)
    D0_new = D0p[keep]
    D1_new = D1t[:, keep] if D1t.numel() else torch.zeros(0, int(keep.sum()), dtype=_DTYPE)
    m_new = mt[keep]
    X_new = Pt.T @ Xt
    return D0_new, D1_new, m_new, X_new


def spectral_radius(L0: torch.Tensor) -> float:
    """谱半径（α_n）的常量估计（detach，仅供 τ 归一化）。

    参数: L0 —— torch.Tensor (N, N)
    返回: float, max(‖L0‖₂, eps)
    """
    return max(float(torch.linalg.matrix_norm(L0.detach(), ord=2)), _SPECTRAL_EPS)


def spectral_tau(L0, K: int = 8, alpha: float = None) -> torch.Tensor:
    """谱形矩 τ_k = tr(T_k(Y))/N，``Y = 2 L0 / α_n − I``（三项递推，可微，无 eigh）。

    参数:
        L0: torch.Tensor, (N, N) 加权图拉普拉斯
        K: int, Chebyshev 截断阶数（≥1）
        alpha: float 或 None, 谱半径；None 时由 ``spectral_radius`` 常量估计
    返回:
        taus: torch.Tensor, (K+1,) 谱形矩向量，taus[k] = τ_k（含 τ_0 = 1）
    """
    L0 = _as_tensor(L0)
    if L0.dim() != 2 or L0.shape[0] != L0.shape[1]:
        raise ValueError(f"L0 必须为二维方阵，当前形状: {tuple(L0.shape)}")
    if K < 1:
        raise ValueError(f"K 必须至少为 1，当前输入: {K}")
    N = L0.shape[0]
    I = torch.eye(N, dtype=_DTYPE)
    a = spectral_radius(L0) if alpha is None else float(alpha)
    if a <= 0:
        raise ValueError(f"alpha 必须大于 0，当前输入: {a}")
    Y = 2.0 * L0 / a - I
    taus = [torch.trace(I) / N]                 # τ_0 = 1
    T_prev, T_cur = I, Y
    taus.append(torch.trace(T_cur) / N)         # τ_1
    for _ in range(2, K + 1):
        T_next = 2.0 * Y @ T_cur - T_prev
        taus.append(torch.trace(T_next) / N)
        T_prev, T_cur = T_cur, T_next
    return torch.stack(taus)


def spectral_cosine_similarity(L0_fine, L0_coarse) -> float:
    """Galerkin 粗粒化的特征值排序余弦相似度（detached，谱保真替代度量）。

    **动机**：原始设计方案 §8 要求 ``τ_k`` 相对误差 ≤5%/≤3%，但实测 Galerkin
    投影 ``L0' = Pᵀ L0 P``（缩减 ≥2×）下 ``τ_k`` 相对误差高达 63%~100%，属
    数学上不可达——因 ``τ_k`` 依赖全谱分布与维度 N，两者在粗粒化后均变。

    实测发现：**特征值排序的相对比例**在 Galerkin 下几乎精确保持（精确模式
    在 C6/三角带/乙醇/随机图 上 cos_sim ∈ [0.996, 1.000]）。这由 Cauchy 交错
    定理保证——粗层特征值被夹在细层相邻特征值之间，排序关系稳定。

    新判据：``cos_sim ≥ 0.90``（精确模式轻松满足，可达）。

    参数:
        L0_fine:   torch.Tensor, (N, N) 细层加权拉普拉斯（detached 内部自动处理）
        L0_coarse: torch.Tensor, (C, C) 粗层加权拉普拉斯（detached 内部自动处理）
    返回:
        float ∈ [-1, 1]，余弦相似度；NaN 表示退化为单节点（C=1）
    """
    Lf = _as_tensor(L0_fine)
    Lc = _as_tensor(L0_coarse)
    if Lf.shape[0] <= 1 or Lc.shape[0] <= 1:
        return float("nan")                            # 退化到 1 节点时无意义
    ev_f = torch.linalg.eigvalsh(Lf.detach()).cpu().numpy()
    ev_c = torch.linalg.eigvalsh(Lc.detach()).cpu().numpy()
    Nf, Nc = len(ev_f), len(ev_c)
    # 把粗层特征值在细层索引空间上做线性插值对齐
    idx = np.linspace(0, Nf - 1, Nc)
    aligned_fine = np.array([np.interp(i, np.arange(Nf), ev_f) for i in idx], dtype=np.float64)
    dot = float(np.dot(ev_c, aligned_fine))
    nf = float(np.linalg.norm(ev_c))
    ng = float(np.linalg.norm(aligned_fine))
    if nf < 1e-30 or ng < 1e-30:
        return float("nan")
    return dot / (nf * ng)


def heat_kernel_trace_distance(L0_fine, L0_coarse, t_list=None) -> float:
    """Galerkin 粗粒化的热核迹相对距离（多 t 取 max，detached）。

    热核 ``exp(-t L0)`` 的迹 ``tr(exp(-t L0)) = Σ exp(-t λ_i)`` 是谱的光滑矩，
    不像 Chebyshev 多项式那样振荡。实测中，当 t ∈ [0.5, 2.0] 时，精确 Galerkin
    下相对误差 ≤ 35%（远好于 τ_k 的 63-100%）。

    新判据：多 t max_rel_err ≤ 40%（精确模式可达）。

    参数:
        L0_fine:   torch.Tensor, (N, N)
        L0_coarse: torch.Tensor, (C, C)
        t_list: list[float] 或 None, 热核时间尺度；None 时取 [0.5, 1.0, 2.0]
    返回:
        float, max_t |tr_c − tr_f| / max(tr_f, 1e-30)
    """
    if t_list is None:
        t_list = [0.5, 1.0, 2.0]
    Lf = _as_tensor(L0_fine)
    Lc = _as_tensor(L0_coarse)
    a = max(float(torch.linalg.matrix_norm(Lf.detach(), ord=2)), 1e-12)
    b = 2.0 * a
    Nf, Nc = int(Lf.shape[0]), int(Lc.shape[0])
    if Nf <= 0 or Nc <= 0:
        return float("inf")
    max_rel = 0.0
    for t in t_list:
        h = lambda x: torch.exp(-float(t) * x)
        ccf = oc.ChainComplex(torch.zeros(1, Nf, dtype=_DTYPE), torch.zeros(0, 1, dtype=_DTYPE))
        calc_f = oc.OperatorCalculus(ccf)
        tr_f = float(torch.trace(calc_f.chebyshev_functional(oc.Operator(Lf.detach()), h, K=32, b=b).M))
        ccc = oc.ChainComplex(torch.zeros(1, Nc, dtype=_DTYPE), torch.zeros(0, 1, dtype=_DTYPE))
        calc_c = oc.OperatorCalculus(ccc)
        tr_c = float(torch.trace(calc_c.chebyshev_functional(oc.Operator(Lc.detach()), h, K=32, b=b).M))
        rel = abs(tr_c - tr_f) / max(abs(tr_f), 1e-30)
        if rel > max_rel:
            max_rel = rel
    return max_rel


def laplacian0_from_DigD(D0, m):
    """由关联矩阵与边权构造加权图拉普拉斯 ``L0 = D0ᵀ diag(m) D0``（可微）。

    参数:
        D0: array-like, (n1, n0)
        m:  array-like, (n1,) 边权（torch 张量时可保留梯度）
    返回: L0 —— torch.Tensor (n0, n0)
    """
    D0t = _as_tensor(D0)
    mt = _as_tensor(m).reshape(-1)
    if mt.shape[0] != D0t.shape[0]:
        raise ValueError(f"m 长度应为 n1={D0t.shape[0]}，当前: {tuple(mt.shape)}")
    return D0t.T @ torch.diag(mt) @ D0t


def build_hierarchy_exact(D0, D1, m, X, max_levels: int = 4, n_min: int = 4):
    """精确模式多层级粗粒化（每层缩减 ≥2×，否则终止）。

    参数:
        D0, D1, m, X: 初始链复形（array-like / tensor）
        max_levels: int, 最大层级数
        n_min: int, 终止阈值（n0 < n_min 停止）
    返回:
        levels: list[tuple(D0, D1, m, X)]，levels[0] 为原始层
    """
    D0c, D1c, mc, Xc = _as_tensor(D0), _as_tensor(D1), _as_tensor(m), _as_tensor(X)
    levels = [(D0c, D1c, mc, Xc)]
    for _ in range(int(max_levels)):
        n0 = D0c.shape[1]
        if n0 < n_min:
            break
        P = tree_partition(D0c, D1c)
        C = P.shape[1]
        if C > n0 // 2:                     # 缩减不足 2× -> 终止
            break
        D0c, D1c, mc, Xc = aggregate_complex(D0c, D1c, mc, Xc, P)
        levels.append((D0c, D1c, mc, Xc))
    return levels


class SoftAggPooler(nn.Module):
    """可学颗粒度池化算子（softmax 软分配）。

    ``P = softmax(Z, dim=1)``，``L0' = Pᵀ L0 P``，``X' = Pᵀ X``，``D0' = D0 P``。
    梯度路径 Z → P → L0' → τ/软秩 → loss，全程矩阵乘与 softmax。
    """

    def __init__(self, n0: int, n_clusters: int = None, seed: int = 0):
        """初始化软分配池化层。

        参数:
            n0: int, 输入顶点数（≥2）
            n_clusters: int 或 None, 目标簇数；None 时取 ceil(n0/2)
            seed: int, 参数初始化随机种子
        """
        super().__init__()
        if n0 < 2:
            raise ValueError(f"n0 必须 ≥ 2，当前输入: {n0}")
        if n_clusters is None:
            n_clusters = max(2, (n0 + 1) // 2)
        if not (2 <= n_clusters < n0):
            raise ValueError(f"n_clusters 必须满足 2 ≤ C < n0，当前: {n_clusters} vs {n0}")
        g = torch.Generator().manual_seed(int(seed))
        self.n0 = int(n0)
        self.n_clusters = int(n_clusters)
        self.Z = nn.Parameter(0.3 * torch.randn(n0, n_clusters, dtype=_DTYPE, generator=g))

    def forward(self, L0, X, D0):
        """前向：软分配 → 粗层拉普拉斯/特征/关联矩阵。

        参数:
            L0: torch.Tensor, (n0, n0) 细层加权拉普拉斯
            X:  torch.Tensor, (n0, d) 顶点特征
            D0: torch.Tensor, (n1, n0) 关联矩阵
        返回:
            (L0', X', D0', P)：粗层拉普拉斯 (C,C)、特征 (C,d)、关联 (n1,C)、软分配 (n0,C)
        """
        L0 = _as_tensor(L0)
        X = _as_tensor(X)
        D0 = _as_tensor(D0)
        if L0.shape[0] != self.n0 or D0.shape[1] != self.n0:
            raise ValueError(f"输入维度应与 n0={self.n0} 一致，当前 L0={tuple(L0.shape)}, D0={tuple(D0.shape)}")
        P = F.softmax(self.Z, dim=1)               # (n0, C)
        L0p = P.T @ L0 @ P
        Xp = P.T @ X
        D0p = D0 @ P
        return L0p, Xp, D0p, P


# ---------------------------------------------------------------------------
# 3. Step 2 前置：分子 → 链复形（输入同态，numpy 复用）
# ---------------------------------------------------------------------------
# 乙醇（与 main.py Phase 5 同款，9 原子 8 键的树，β₁ = 0）
ETHANOL_ATOMTYPES = ["c3", "c3", "oh", "hc", "hc", "hc", "h1", "h1", "ho"]
ETHANOL_BONDS = [(0, 1), (0, 3), (0, 4), (0, 5), (1, 2), (1, 6), (1, 7), (2, 8)]
ETHANOL_POSITIONS = np.array([
    [0.0, 0.0, 0.0], [1.52, 0.0, 0.0], [2.15, 1.35, 0.0],
    [-0.5, 0.9, 0.3], [-0.5, -0.9, -0.3], [-0.5, 0.0, -0.9],
    [1.52, -0.9, 0.9], [1.52, 0.9, -0.9], [2.15, 1.35, 0.96],
], dtype=np.float64)


def _complex_from_adjacency(A_s: np.ndarray, max_cycle_len: int = None):
    """由 SRE 平滑邻接 A_s 构造链复形（边 = 正支撑，2-面 = 简单环填充）。

    参数:
        A_s: np.ndarray, (n0, n0) SRE 平滑邻接（W_e ⊙ P+）
        max_cycle_len: int 或 None, 环枚举最大长度；None 取 n0
    返回:
        (D0, D1, edge_index, faces, m0)，numpy：
            D0 (n1, n0)、D1 (n2, n1)、edge_index list[(u,v)]、faces list[list[int]]、
            m0 (n1,) = A_s 在边上的权重
    """
    A = np.asarray(A_s, dtype=np.float64)
    if A.ndim != 2 or A.shape[0] != A.shape[1]:
        raise ValueError(f"A_s 必须为二维方阵，当前形状: {A.shape}")
    n0 = A.shape[0]
    edges = [(u, v) for u in range(n0) for v in range(u + 1, n0) if A[u, v] > _ZERO_TOL]
    n1 = len(edges)
    D0 = np.zeros((n1, n0))
    m0 = np.zeros(n1)
    for e, (u, v) in enumerate(edges):
        D0[e, u] = -1.0
        D0[e, v] = +1.0
        m0[e] = A[u, v]

    suite = SREElectronicOperatorSuite(enable_debug_log=False)
    sup = (A > _ZERO_TOL).astype(np.float64)
    cycles = suite.enumerate_simple_cycles(sup, n0 if max_cycle_len is None else max_cycle_len)

    edge_dir = {(u, v): e for e, (u, v) in enumerate(edges)}
    faces, D1 = [], np.zeros((len(cycles), n1))
    for f, cyc in enumerate(cycles):
        faces.append([int(x) for x in cyc])
        L = len(cyc)
        for i in range(L):
            s, t = int(cyc[i]), int(cyc[(i + 1) % L])
            if (s, t) in edge_dir:
                D1[f, edge_dir[(s, t)]] += 1.0
            elif (t, s) in edge_dir:
                D1[f, edge_dir[(t, s)]] -= 1.0
    return D0, D1, edges, faces, m0


def build_chain_complex_from_molecule(positions, atomtypes, bonds=None, max_cycle_len: int = None):
    """分子 → 链复形（复用正典 infer_bonds / build_sre_smooth_adjacency / 环枚举）。

    参数:
        positions: np.ndarray, (N, 3) 原子坐标
        atomtypes: list, GAFF2 atomtype 列表
        bonds: list[(int,int)] 或 None, 化学键；None 时由坐标推断
        max_cycle_len: int 或 None, 环枚举最大长度
    返回:
        (D0, D1, edge_index, faces)（numpy；不含边权，见 build_chain_complex_with_weights）
    """
    D0, D1, edge_index, faces, _ = build_chain_complex_with_weights(
        positions, atomtypes, bonds=bonds, max_cycle_len=max_cycle_len)
    return D0, D1, edge_index, faces


def build_chain_complex_with_weights(positions, atomtypes, bonds=None, max_cycle_len: int = None):
    """分子 → 链复形 + 边权 W_e + 电负性（Step 2 输入同态一次性给出）。

    参数:
        positions: np.ndarray, (N, 3) 原子坐标
        atomtypes: list, GAFF2 atomtype 列表
        bonds: list[(int,int)] 或 None, 化学键
        max_cycle_len: int 或 None, 环枚举最大长度
    返回:
        (D0, D1, edge_index, faces, m0, chi)：
            m0 (n1,) = W_e|_edge（Op4 涌现边权），chi (N,) = Pauling 电负性
    """
    suite = SREElectronicOperatorSuite(enable_debug_log=False)
    A_s = suite.build_sre_smooth_adjacency(positions, atomtypes=atomtypes, bonds=bonds)
    D0, D1, edge_index, faces, m0 = _complex_from_adjacency(A_s, max_cycle_len=max_cycle_len)
    chi = suite.electronegativities_from_atomtypes(atomtypes) if atomtypes else np.zeros(A_s.shape[0])
    return D0, D1, edge_index, faces, m0, chi


# ---------------------------------------------------------------------------
# 4. Step 2：尺度规范固定 + 谱特征
# ---------------------------------------------------------------------------
class ScaleGauge(nn.Module):
    """尺度规范固定：把整体尺度自由度从边权中分离并锁定。

    ``m = s · ŵ``，``ŵ = softplus(rho) / mean(softplus(rho))``（mean(ŵ)=1）。
    因 ``τ_k`` 在 ``m → c·m`` 下不变，故 ``m`` 的平坦方向被消除；
    原型阶段冻结 ``s = s0 = mean(m0)``（``learnable_scale=False``）。
    """

    def __init__(self, n1: int, s0: float = 1.0, learnable_scale: bool = False):
        """初始化尺度规范层。

        参数:
            n1: int, 边数（≥1）
            s0: float, 冻结尺度（通常取 mean(m0)）
            learnable_scale: bool, True 时 s 参与训练（需配合 L_gauge）
        """
        super().__init__()
        if n1 < 1:
            raise ValueError(f"n1 必须 ≥ 1，当前输入: {n1}")
        self.n1 = int(n1)
        self.rho = nn.Parameter(torch.zeros(self.n1, dtype=_DTYPE))
        s_t = torch.as_tensor(float(s0), dtype=_DTYPE)
        self.learnable_scale = bool(learnable_scale)
        if self.learnable_scale:
            self.s = nn.Parameter(s_t)
        else:
            self.register_buffer("s", s_t)

    def forward(self, rho=None, s0=None):
        """前向：rho（或 s0）→ (m, s, w_hat)。

        参数:
            rho: torch.Tensor 或 None, (n1,) 未约束对数尺度参数；None 用内部参数
            s0: float 或 None, 覆盖冻结尺度；None 用内部 s
        返回:
            (m, s, w_hat)：m = s·ŵ (n1,)、s 标量张量、ŵ 归一化边权 (n1,)
        """
        r = self.rho if rho is None else _as_tensor(rho).reshape(-1)
        if r.shape[0] != self.n1:
            raise ValueError(f"rho 长度应为 n1={self.n1}，当前: {tuple(r.shape)}")
        w = F.softplus(r) + 1e-6
        w_hat = w / w.mean()
        s = self.s if s0 is None else torch.as_tensor(float(s0), dtype=_DTYPE)
        return s * w_hat, s, w_hat


def _level_spectral_features(D0, D1, m, K: int):
    """单层谱特征：τ_k（K+1 维）⊕ [α_n, λ₂]。

    参数:
        D0, D1, m: 该层链复形与边权
        K: int, Chebyshev 阶数
    返回:
        feat: torch.Tensor, (K+3,)
    """
    L0 = laplacian0_from_DigD(D0, m)
    tau = spectral_tau(L0, K=K)
    alpha = spectral_radius(L0)
    ev = torch.linalg.eigvalsh(L0.detach())
    lam2 = float(ev[1]) if ev.shape[0] > 1 else float(ev[0])
    extra = torch.as_tensor([alpha, max(lam2, 0.0)], dtype=_DTYPE)
    return torch.cat([tau, extra])


class SRETopoEncoder(nn.Module):
    """多颗粒度拓扑编码器：逐层输出谱特征。

    层级由精确模式（β₁ 严格不变）连通块聚合生成，故层级索引掩码与 ``m`` 无关，
    只有 ``m[keep]`` 的选取保留梯度；**可学颗粒度**由独立模块 ``SoftAggPooler`` 承担。
    """

    def __init__(self, K: int = 8, max_levels: int = 4, n_min: int = 4, target_size: int = 4):
        """初始化编码器。

        参数:
            K: int, Chebyshev 阶数
            max_levels: int, 最大层级数
            n_min: int, 层级终止阈值（n0 < n_min 停止）
            target_size: int, 精确聚合的目标块规模
        """
        super().__init__()
        self.K = int(K)
        self.max_levels = int(max_levels)
        self.n_min = int(n_min)
        self.target_size = int(target_size)

    def forward(self, complex_, m, X=None, D1=None):
        """前向：生成多层级并逐层返回谱特征。

        参数:
            complex_: tuple(D0, D1, ...) 或 D0 张量
            m: torch.Tensor, (n1,) 边权（可含梯度）
            X: torch.Tensor 或 None, (n0, d) 顶点特征；None 时用列向量 1
            D1: 覆盖 complex_ 中的 D1（可选）
        返回:
            feats: dict[int, torch.Tensor]，键为层级索引，值为 (K+3,) 谱特征
        """
        if isinstance(complex_, (tuple, list)):
            D0 = complex_[0]
            D1_ = complex_[1] if len(complex_) > 1 else None
        else:
            D0, D1_ = complex_, None
        if D1 is not None:
            D1_ = D1
        D0 = _as_tensor(D0)
        n0 = int(D0.shape[1])
        if X is None:
            X = torch.ones(n0, 1, dtype=_DTYPE)
        levels = build_hierarchy_exact(D0, D1_, m, _as_tensor(X),
                                       max_levels=self.max_levels, n_min=self.n_min)
        feats = {}
        for l, (D0l, D1l, ml, Xl) in enumerate(levels):
            feats[l] = _level_spectral_features(D0l, D1l, ml, self.K)
        return feats


class LevelAttentionHead(nn.Module):
    """层级注意力 + MLP 头：对多层级特征加权聚合后输出标量/向量。"""

    def __init__(self, feat_dim: int, out_dim: int, hidden: int = 32):
        """初始化注意力头。

        参数:
            feat_dim: int, 单层特征维数
            out_dim: int, 输出维数
            hidden: int, MLP 隐层宽度
        """
        super().__init__()
        if feat_dim < 1 or out_dim < 1:
            raise ValueError(f"feat_dim/out_dim 必须 ≥ 1，当前: {feat_dim}, {out_dim}")
        self.score = nn.Linear(feat_dim, 1)
        self.mlp = nn.Sequential(nn.Linear(feat_dim, hidden), nn.Tanh(), nn.Linear(hidden, out_dim))

    def forward(self, level_features):
        """前向：层级注意力聚合 → MLP。

        参数:
            level_features: dict[int, tensor] 或 list[tensor]，每项 (feat_dim,)
        返回:
            out: torch.Tensor, (out_dim,)
        """
        if isinstance(level_features, dict):
            seq = [level_features[k] for k in sorted(level_features.keys())]
        else:
            seq = list(level_features)
        if len(seq) == 0:
            raise ValueError("level_features 不能为空")
        Fm = torch.stack([_as_tensor(x).reshape(-1) for x in seq], dim=0)   # (L, feat_dim)
        a = torch.softmax(self.score(Fm).squeeze(-1), dim=0)               # (L,)
        z = (a[:, None] * Fm).sum(dim=0)                                    # (feat_dim,)
        return self.mlp(z)


def _observation(L0: torch.Tensor, X: torch.Tensor, K: int = 24, b: float = None):
    """谱滤波观测 Y = g(L0) X（Chebyshev 函数演算，可微、免 eigh）。

    参数:
        L0: torch.Tensor, (N, N)
        X: torch.Tensor, (N, d) 多探针
        K: int, Chebyshev 阶数
        b: float 或 None, 谱上界
    返回:
        Y: torch.Tensor, (N, d)
    """
    L0 = _as_tensor(L0)
    X = _as_tensor(X)
    cc = oc.ChainComplex(torch.zeros(1, L0.shape[0], dtype=_DTYPE), torch.zeros(0, 1, dtype=_DTYPE))
    calc = oc.OperatorCalculus(cc)
    g = lambda t: torch.exp(-0.35 * t)
    return calc.chebyshev_functional(oc.Operator(L0), g, K=K, b=b).M @ X


def _soft_rank(D0, D1, m, K: int = 48, sharp: float = 80.0):
    """软秩闭环量 ``tr h(L1n)``（``L1n = L1 / ‖L1‖₂``，``h(t) = exp(−sharp·t)``）。

    ``L1 = D0 D0ᵀ + D1ᵀ D1``（Hodge 1-拉普拉斯，不含 ``m``）。谱归一化后其零空间
    （调和/环模，维数 = β₁）贡献恰 1；取足够锐的 ``sharp`` 使非零模贡献趋于 0，
    故 ``tr h(L1n) ≈ β₁``。标定结果（``sharp=80, K=48``）：
    裸环 C₆（β₁=1）→ 1.0000；乙醇树（β₁=0）→ 0.019，均落在判据 ``≤0.1`` 内。

    本量结构性、对 ``m`` 无可微路径，仅作 β₁ 闭环诊断。

    参数:
        D0, D1, m: 该层链复形与边权（``m`` 不参与 ``L1`` 计算）
        K: int, Chebyshev 阶数
        sharp: float, 谱衰减锐度（越大越逼近 β₁）
    返回:
        torch.Tensor 标量
    """
    D0t = _as_tensor(D0)
    D1t = _as_tensor(D1)
    n1 = int(D0t.shape[0])
    L1 = D0t @ D0t.T + (D1t.T @ D1t if D1t.numel() else torch.zeros(n1, n1, dtype=_DTYPE))
    b = max(float(torch.linalg.matrix_norm(L1.detach(), ord=2)), 1e-12)
    L1n = L1 / b
    cc = oc.ChainComplex(torch.zeros(1, n1, dtype=_DTYPE), torch.zeros(0, 1, dtype=_DTYPE))
    calc = oc.OperatorCalculus(cc)
    h = lambda t: torch.exp(-float(sharp) * t)
    return torch.trace(calc.chebyshev_functional(oc.Operator(L1n), h, K=K).M)


def run_selfsupervised_demo(seed: int = 0, iters: int = 1200, K: int = 8, P: int = 24,
                            verbose: bool = True):
    """最小可训练原型：真实分子图 + 多颗粒度自监督反演。

    自监督任务：真值 ``m*`` → 观测 ``Y* = g(L0(m*)) X``；模型 ``ŷ = g(L0(m)) X``。
    损失按方案 §6 更新（τ 不可达判据已替换）：
    ``L = L_task + λ_g L_gauge + λ_s L_spec + λ_h L_hom``
    （``L_gauge`` 仅在 ``learnable_scale=True`` 时加入；原型阶段 ``s`` 冻结）。
        L_task = mean((ŷ − Y*)²)                 （反演主损失，即「自监督 loss」）
        L_head = mean((τ̂ − τ*)²)                （多颗粒度特征 + 层级注意力头，辅助）
        L_gauge = (α_n(m) − α_n(m0))²           （仅 s 可学时）
        L_spec  = −cos_sim(L0, L0')              （特征值排序余弦相似度，最大化）
        L_hom   = |tr h(L1n') − tr h(L1n)|      （粗/细层软秩差，闭环 β₁）

    **关于 L_spec 的诚实边界（§8 替代方案）**：原始设计要求 ``τ_k`` 相对误差 ≤5%，
    但实测 Galerkin 粗粒化（精确模式，缩减 ≥2×）下 ``τ_k`` 相对误差达 63%~100%——
    数学上不可达（依赖全谱+维度，二者皆变）。替代为**特征值排序余弦相似度**：
        cos_sim ≥ 0.90（精确模式实测 0.996~1.000，远超阈值，可达）
    由 Cauchy 交错定理保证特征值排序关系稳定。
    热核迹距离（hkt）在极端缩减/β₀ 变化时不稳定，已放弃。

    参数:
        seed: int, 随机种子
        iters: int, 优化迭代数
        K: int, Chebyshev 阶数（τ 与特征维）
        P: int, 观测探针数
        verbose: bool, 是否打印过程
    返回:
        dict：loss0/loss1（L_task）、loss_total、corr(ŵ, w*)、mae、w_hat、w_true、
              tau_hat、tau_star、hom_fine、hom_coarse、spec_cos_sim
    """
    torch.manual_seed(seed)
    np.random.seed(seed)

    D0, D1, edge_index, faces, m0, chi = build_chain_complex_with_weights(
        ETHANOL_POSITIONS, ETHANOL_ATOMTYPES, bonds=ETHANOL_BONDS)
    D0t, D1t = _as_tensor(D0), _as_tensor(D1)
    n0, n1 = int(D0t.shape[1]), int(D0t.shape[0])

    # 反演目标由固定生成器给出（与优化随机性解耦，保证可复现与可辨识）
    g_t = torch.Generator().manual_seed(1234)
    m_star = 0.5 + 1.5 * torch.rand(n1, dtype=_DTYPE, generator=g_t)
    g_x = torch.Generator().manual_seed(1235)
    X = torch.randn(n0, P, dtype=_DTYPE, generator=g_x)
    with torch.no_grad():
        L0_star = laplacian0_from_DigD(D0t, m_star)
        Y_star = _observation(L0_star, X, K=32)
        tau_star = spectral_tau(L0_star, K=K)
        alpha_star = spectral_radius(L0_star)
        hom_fine = _soft_rank(D0t, D1t, m_star)

    learnable_scale = False
    gauge = ScaleGauge(n1, s0=float(m_star.mean()), learnable_scale=learnable_scale)
    pool = SoftAggPooler(n0, n_clusters=(n0 + 1) // 2, seed=0)
    enc = SRETopoEncoder(K=K, max_levels=4, n_min=4, target_size=4)
    head = LevelAttentionHead(feat_dim=K + 3, out_dim=K + 1, hidden=32)
    params = list(gauge.parameters()) + list(pool.parameters()) + list(head.parameters())
    opt = torch.optim.Adam(params, lr=0.08)

    lam_g, lam_s, lam_h, lam_head = 1.0, 0.1, 1.0, 0.001

    def loss_of():
        m, s, w_hat = gauge()
        L0 = laplacian0_from_DigD(D0t, m)
        y_hat = _observation(L0, X, K=32)
        l_task = torch.mean((y_hat - Y_star) ** 2)

        feats = enc((D0t, D1t), m, X=X)
        tau_hat = head(feats)
        l_head = torch.mean((tau_hat - tau_star) ** 2)

        l_gauge = torch.zeros((), dtype=_DTYPE)
        if learnable_scale:
            l_gauge = (spectral_radius(L0) - alpha_star) ** 2

        # ------------------------------------------------------------------
        # L_spec：可微谱保真 loss —— 热核迹相对距离
        # ==================================================================
        # **梯度路径**（从 loss 反向回到 SoftAggPooler 的 Z）：
        #
        #   L_spec ──► |tr_c − tr_f| / tr_f ──► tr_c ──► tr(exp(−t L0p))
        #     ▲                                    ▲
        #     │                                    │
        #     │                       chebyshev_functional(Y) 三项递推
        #     │                                    ▲
        #     │                                    │
        #     │                                Y = 2 L0p / b − I
        #     │                                    ▲
        #     │                                    │
        #     └──── L0p = Pᵀ L0_op P ◄── P = softmax(Z)
        #                  ↑
        #                  │
        #              L0_op = L0.detach()
        #              （detach 切断 L0 ──► m 的梯度，让 L_spec 只训练 Z）
        #
        # **每一步的可微性论证**：
        #
        # (1) P = softmax(Z)：softmax 是标准可微算子，∂P/∂Z 有闭式
        #     ∂P[:,j]/∂Z[:,k] = P[:,j] (δ_jk − P[:,k])
        #
        # (2) L0p = Pᵀ L0_op P：双线性型，L0_op detach 视为常量
        #     ∂L0p/∂P = L0_op P + L0_opᵀ P = 2 L0_op P（L0 对称）
        #
        # (3) Y = 2 L0p / b − I：线性缩放，∂Y/∂L0p = 2/b · I
        #
        # (4) chebyshev_functional 三项递推：
        #     T_0 = I,  T_1 = Y,  T_{k+1} = 2 Y T_k − T_{k-1}
        #     每步是矩阵乘 + 线性组合，autograd 可精确追踪
        #     ∂T_{k+1}/∂Y = 2 T_k + 2 Y ∂T_k/∂Y − ∂T_{k-1}/∂Y（链式展开）
        #     最终 g(Y) = Σ c_k T_k(Y)，系数 c_k 是常量（由谱节点采样得到）
        #
        # (5) tr_c = tr(g(Y))：迹是线性的，∂tr/∂M = I（任何方阵 M）
        #
        # (6) tr_f = float(...)：**Python float，在 loss 中视为常量**
        #     —— 这是刻意设计：L_spec 只训练 Z，不干扰 m 的反演
        #
        # (7) |tr_c − tr_f| / tr_f：relu 型的绝对值函数 + 除法
        #     ∂|x|/∂x = sign(x)（autograd 用 subgradient ±1）
        #
        # **为什么不把 L0_op 也设为可微？**
        #   若 L0_op 不 detach，梯度会沿 L0_op ──► L0 ──► m 回传，
        #   与 L_task（让 m 拟合观测）的梯度方向冲突。实测会导致反演发散
        #   （loss → 1e-1, corr ≈ −0.17），与之前 τ 匹配不可微时的退化一致。
        #   解耦后 L_spec 只训练 pooler 的 Z，L_task/L_head 训练 m + head，
        #   各自职责清晰。
        #
        # **为什么选 t ∈ [1.0, 2.0]？**
        #   t 太小（≤ 0.5）：exp(−t λ) ≈ 1 对小 λ 几乎无区分度，热核迹退化到 N'
        #                    （节点数），谱信息丢失
        #   t 太大（≥ 5.0）：exp(−t λ) → 0 对 λ > 0 全部压平，热核迹退化到 β₀
        #                    （连通分量数），同样丢失谱形状
        #   t ∈ [1.0, 2.0]：exp(−t λ) 在谱中部有最强变化，是最有信息量的区间
        # ------------------------------------------------------------------
        L0_op = L0.detach()
        L0p, _, _, _ = pool(L0_op, torch.ones(n0, 1, dtype=_DTYPE), D0t)
        a = max(float(torch.linalg.matrix_norm(L0_op.detach(), ord=2)), 1e-12)
        b = 2.0 * a
        t_list = [1.0, 2.0]
        l_spec_terms = []
        cc_f = oc.ChainComplex(torch.zeros(1, L0_op.shape[0], dtype=_DTYPE),
                               torch.zeros(0, 1, dtype=_DTYPE))
        calc_f = oc.OperatorCalculus(cc_f)
        for t in t_list:
            h = lambda x, tt=t: torch.exp(-float(tt) * x)
            # 细层 tr(exp(-tL0)) 是常量（L0_op detached，返回 Python float）
            tr_f = float(torch.trace(calc_f.chebyshev_functional(
                oc.Operator(L0_op), h, K=32, b=b).M))
            # 粗层 tr(exp(-tL0p)) 是可微的（L0p 来自 Z）
            cc_c = oc.ChainComplex(torch.zeros(1, L0p.shape[0], dtype=_DTYPE),
                                   torch.zeros(0, 1, dtype=_DTYPE))
            calc_c = oc.OperatorCalculus(cc_c)
            tr_c = torch.trace(calc_c.chebyshev_functional(
                oc.Operator(L0p), h, K=32, b=b).M)
            l_spec_terms.append(torch.abs(tr_c - tr_f) / max(tr_f, 1e-30))
        l_spec = torch.stack(l_spec_terms).mean()


        # L_hom：粗/细层软秩差（结构性，对 m 无可微路径）
        D0c, D1c, mc, _ = build_hierarchy_exact(D0t, D1t, m, X, max_levels=2, n_min=4)[-1]
        l_hom = torch.abs(_soft_rank(D0c, D1c, mc) - hom_fine)

        total = l_task + lam_head * l_head + lam_g * l_gauge + lam_s * l_spec + lam_h * l_hom
        return total, l_task, l_head, l_gauge, l_spec, l_hom, tau_hat, m, w_hat

    with torch.no_grad():
        total0, l_task0, *_ = loss_of()
    for _ in range(int(iters)):
        opt.zero_grad()
        total, l_task, l_head, l_gauge, l_spec, l_hom, tau_hat, m, w_hat = loss_of()
        total.backward()
        opt.step()

    with torch.no_grad():
        total1, l_task1, l_head1, l_gauge1, l_spec1, l_hom1, tau_hat1, m1, w_hat1 = loss_of()
        w_hat_np = (w_hat1 / w_hat1.mean()).numpy()
        w_true_np = (m_star / m_star.mean()).numpy()
        corr = float(np.corrcoef(w_hat_np, w_true_np)[0, 1])
        mae = float(np.mean(np.abs(w_hat_np - w_true_np)))
        D0c, D1c, mc, _ = build_hierarchy_exact(D0t, D1t, m1, X, max_levels=2, n_min=4)[-1]
        hom_coarse = float(_soft_rank(D0c, D1c, mc))
        # 最终谱保真度量（detached）
        L0_final = laplacian0_from_DigD(D0t.detach(), m1.detach())
        L0p_final, _, _, _ = pool(L0_final, torch.ones(n0, 1, dtype=_DTYPE), D0t.detach())
        spec_cos = spectral_cosine_similarity(L0_final, L0p_final)

    if verbose:
        print("[自监督 demo] 真实分子图（乙醇）+ 多颗粒度")
        print(f"  链复形: n0={n0}, n1={n1}, n2={int(D1t.shape[0])}  β₁={exact_beta(D0t, D1t)[1]}")
        print(f"  L_task(自监督 loss): {float(l_task0):.3e} -> {float(l_task1):.3e}")
        print(f"  L_head={float(l_head1):.3e}  L_gauge={float(l_gauge1):.3e}  "
              f"L_spec={float(l_spec1):.3e}  L_hom={float(l_hom1):.3e}")
        print(f"  谱保真 cos_sim={spec_cos:.4f}  (精确模式可达 ≥0.90)")
        print(f"  软秩 β₁: fine={float(hom_fine):.4f} -> coarse={hom_coarse:.4f}")
        print(f"  corr(ŵ, w*) = {corr:.4f}   MAE = {mae:.4e}")

    return {"loss0": float(l_task0), "loss1": float(l_task1), "loss_total": float(total1),
            "corr": corr, "mae": mae, "w_hat": w_hat_np, "w_true": w_true_np,
            "tau_hat": tau_hat1.detach().numpy(), "tau_star": tau_star.detach().numpy(),
            "hom_fine": float(hom_fine), "hom_coarse": hom_coarse,
            "spec_cos_sim": spec_cos}


# ---------------------------------------------------------------------------
# 5. Step 3/4：四类硬测试
# ---------------------------------------------------------------------------
def _spectral_dimension(L0: torch.Tensor, n_points: int = 24):
    """谱维度 d_s = 2·d log N(λ) / d log λ（由态密度计数函数拟合，非预设维度）。

    参数:
        L0: torch.Tensor, (N, N) 加权拉普拉斯
        n_points: int, 拟合窗口点数
    返回:
        (d_s, r2)：谱维度估计与线性拟合 R²
    """
    ev = torch.linalg.eigvalsh(L0.detach()).numpy()
    ev = np.sort(ev)
    lam = ev[ev > 1e-9]
    if lam.size < 4:
        return float("nan"), 0.0
    Ntot = lam.size
    grid = np.logspace(np.log10(lam[0] * 1.01), np.log10(lam[-1]), n_points)
    Nlam = np.array([np.sum(ev <= g) for g in grid], dtype=float) / Ntot
    mask = (Nlam > 0.05) & (Nlam < 0.95)
    if mask.sum() < 3:
        return float("nan"), 0.0
    x = np.log(grid[mask])
    y = np.log(Nlam[mask])
    A = np.vstack([x, np.ones_like(x)]).T
    slope, intercept = np.linalg.lstsq(A, y, rcond=None)[0]
    y_hat = A @ np.array([slope, intercept])
    ss_res = float(np.sum((y - y_hat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - ss_res / max(ss_tot, 1e-30)
    return float(2.0 * slope), float(r2)


def _invert_molecule(seed: int, iters: int, K: int, P: int, lr: float = 0.08,
                     target_seed: int = 1234):
    """从指定初值做一次自监督反演，返回归一化边权与观测残差。

    反演目标（真值 ``m*`` 与探针 ``X``）由 ``target_seed`` 固定，与初值种子
    ``seed`` 解耦，故不同初值对应**同一**反演问题，可直接比较收敛吸引子。

    参数:
        seed: int, 初值随机种子
        iters: int, 迭代数
        K: int, τ 阶数；P: int, 探针数；lr: float, 学习率
        target_seed: int, 反演目标（真值/探针）固定种子
    返回:
        (w_hat, L_task)
    """
    D0, D1, _, _, m0, _ = build_chain_complex_with_weights(
        ETHANOL_POSITIONS, ETHANOL_ATOMTYPES, bonds=ETHANOL_BONDS)
    D0t, D1t = _as_tensor(D0), _as_tensor(D1)
    n0, n1 = int(D0t.shape[1]), int(D0t.shape[0])

    g_t = torch.Generator().manual_seed(int(target_seed))
    m_star = 0.5 + 1.5 * torch.rand(n1, dtype=_DTYPE, generator=g_t)
    g_x = torch.Generator().manual_seed(int(target_seed) + 1)
    X = torch.randn(n0, P, dtype=_DTYPE, generator=g_x)
    with torch.no_grad():
        Y_star = _observation(laplacian0_from_DigD(D0t, m_star), X, K=32)

    gauge = ScaleGauge(n1, s0=float(m_star.mean()))
    if seed != 0:
        with torch.no_grad():
            g_i = torch.Generator().manual_seed(int(seed))
            gauge.rho.add_(0.5 * torch.randn(n1, dtype=_DTYPE, generator=g_i))   # 不同初值
    opt = torch.optim.Adam(gauge.parameters(), lr=lr)

    for _ in range(int(iters)):
        opt.zero_grad()
        m, s, w_hat = gauge()
        y_hat = _observation(laplacian0_from_DigD(D0t, m), X, K=32)
        loss = torch.mean((y_hat - Y_star) ** 2)
        loss.backward()
        opt.step()
    with torch.no_grad():
        m, s, w_hat = gauge()
        y_hat = _observation(laplacian0_from_DigD(D0t, m), X, K=32)
        loss = float(torch.mean((y_hat - Y_star) ** 2))
        return (w_hat / w_hat.mean()).numpy(), loss


def _make_rmat_complex(n: int = 16, edge_factor: int = 2, seed: int = 7):
    """构造 RMAT 风格随机图链复形（跨域迁移用，非分子图）。

    参数:
        n: int, 顶点数；edge_factor: int, 边数 ≈ n·edge_factor；seed: int, 随机种子
    返回:
        (D0, D1, m0)
    """
    rng = np.random.RandomState(seed)
    target = n * edge_factor
    edges = set()
    while len(edges) < target:
        u, v = int(rng.randint(0, n)), int(rng.randint(0, n))
        if u == v:
            continue
        edges.add((min(u, v), max(u, v)))
    edges = sorted(edges)
    n1 = len(edges)
    D0 = np.zeros((n1, n))
    for e, (u, v) in enumerate(edges):
        D0[e, u] = -1.0
        D0[e, v] = +1.0
    m0 = 0.5 + 1.5 * np.random.RandomState(seed + 1).rand(n1)
    return D0, np.zeros((0, n1)), m0


def run_hard_tests(verbose: bool = True):
    """四类硬测试（方案 §7）：维度涌现、先验不变性、跨域迁移、算子层 vs MLP 消融。

    参数:
        verbose: bool, 是否打印结果
    返回:
        dict，含各项结果与 pass 标志
    """
    results = {}

    # --- 硬测试 1：维度涌现（谱维度 d_s 是否收敛到稳定值，而非预设 4）---
    # 在 RMAT 图上做多层级，n0 足够大以支持 d_s 拟合（n0 ≥ 6）
    D0d, D1d, m0d = _make_rmat_complex(n=24, edge_factor=2, seed=11)
    D0dt, D1dt, m0dt = _as_tensor(D0d), _as_tensor(D1d), _as_tensor(m0d)
    Xd = torch.ones(int(D0dt.shape[1]), 1, dtype=_DTYPE)
    levels = build_hierarchy_exact(D0dt, D1dt, m0dt, Xd, max_levels=4, n_min=4)
    ds_vals = []
    for D0l, D1l, ml, _ in levels:
        n0l = int(D0l.shape[1])
        if n0l < 6:
            ds_vals.append({"n0": n0l, "d_s": None, "r2": None})
            continue
        ds, r2 = _spectral_dimension(laplacian0_from_DigD(D0l, ml))
        ds_vals.append({"n0": n0l, "d_s": ds, "r2": r2})
    finite = [d["d_s"] for d in ds_vals if d["d_s"] is not None and np.isfinite(d["d_s"])]
    ds_std = float(np.std(finite)) if len(finite) > 1 else 0.0
    results["dimension_emergence"] = {
        "levels": ds_vals, "d_s_std": ds_std,
        "pass": bool(len(finite) >= 1 and np.all(np.isfinite(finite))),
    }

    # --- 硬测试 2：先验不变性（多初值收敛到同一吸引子）---
    iters_prior, P_prior, K_prior = 1200, 24, 8
    hats, losses = [], []
    for s in (0, 1, 2):
        w_hat, l_task = _invert_molecule(s, iters_prior, K_prior, P_prior)
        hats.append(w_hat)
        losses.append(l_task)
    dists = [float(np.max(np.abs(hats[i] - hats[j]))) for i in range(3) for j in range(i + 1, 3)]
    results["prior_invariance"] = {
        "pairwise_max_dist": dists, "max_dist": float(np.max(dists)),
        "losses": losses,
        "pass": bool(np.max(dists) <= 1e-6),
    }

    # --- 硬测试 3：跨域迁移（分子上训练 → 图 zero-shot）---
    D0r, D1r, m0r = _make_rmat_complex(n=16, edge_factor=2, seed=7)
    D0rt, D1rt, m0rt = _as_tensor(D0r), _as_tensor(D1r), _as_tensor(m0r)
    n0r = int(D0rt.shape[1])
    Xr = torch.randn(n0r, 24, dtype=_DTYPE)
    with torch.no_grad():
        tau_r_star = spectral_tau(laplacian0_from_DigD(D0rt, m0rt), K=K_prior)
    # zero-shot：用分子上训练得到的 gauge/head 直接预测 RMAT 的 τ（不微调）
    D0m, D1m, _, _, m0m, _ = build_chain_complex_with_weights(
        ETHANOL_POSITIONS, ETHANOL_ATOMTYPES, bonds=ETHANOL_BONDS)
    D0mt, D1mt = _as_tensor(D0m), _as_tensor(D1m)
    g_t = ScaleGauge(int(D0mt.shape[0]), s0=float(_as_tensor(m0m).mean()))
    enc_t = SRETopoEncoder(K=K_prior)
    head_t = LevelAttentionHead(feat_dim=K_prior + 3, out_dim=K_prior + 1)
    opt_t = torch.optim.Adam(list(g_t.parameters()) + list(head_t.parameters()), lr=0.08)
    m_star_m = _as_tensor(m0m)
    Xm = torch.randn(int(D0mt.shape[1]), 24, dtype=_DTYPE)
    with torch.no_grad():
        tau_m_star = spectral_tau(laplacian0_from_DigD(D0mt, m_star_m), K=K_prior)
    for _ in range(600):
        opt_t.zero_grad()
        m, _, _ = g_t()
        feats = enc_t((D0mt, D1mt), m, X=Xm)
        loss = torch.mean((head_t(feats) - tau_m_star) ** 2)
        loss.backward()
        opt_t.step()
    with torch.no_grad():
        g_r = ScaleGauge(int(D0rt.shape[0]), s0=float(m0rt.mean()))
        feats_r = enc_t((D0rt, D1rt), g_r()[0], X=Xr)
        tau_pred = head_t(feats_r)
        transfer_res = float(torch.mean(torch.abs(tau_pred - tau_r_star) / (1.0 + torch.abs(tau_r_star))))
    results["cross_domain_transfer"] = {
        "zero_shot_rel_residual": transfer_res,
        "pass": bool(np.isfinite(transfer_res)),
    }

    # --- 硬测试 4：消融（算子层 vs 同参数量 MLP head）---
    # 任务：区分 β₁=0（乙醇树）与 β₁=1（C6 环）两类图（粒度可分性代理任务）
    torch.manual_seed(0)
    samples = []
    for _ in range(8):
        D0e, D1e, _, _, m0e, _ = build_chain_complex_with_weights(
            ETHANOL_POSITIONS, ETHANOL_ATOMTYPES, bonds=ETHANOL_BONDS)
        samples.append((D0e, D1e, m0e, 0))
        cyc = np.zeros((6, 6))
        for i in range(6):
            cyc[i, (i + 1) % 6] = cyc[(i + 1) % 6, i] = 1.0
        D0c_, D1c_, _, _, m0c = _complex_from_adjacency(cyc)
        samples.append((D0c_, D1c_, m0c, 1))

    def op_features(D0s, D1s, ms):
        D0tt, D1tt = _as_tensor(D0s), _as_tensor(D1s)
        feats = SRETopoEncoder(K=K_prior)
        f = feats((D0tt, D1tt), _as_tensor(ms), X=torch.ones(int(D0tt.shape[1]), 1, dtype=_DTYPE))
        return torch.cat([f[k] for k in sorted(f.keys())])          # 多颗粒度算子特征

    def mlp_features(D0s, D1s, ms):
        L0 = laplacian0_from_DigD(_as_tensor(D0s), _as_tensor(ms))
        ev = torch.linalg.eigvalsh(L0.detach())
        k = min(4, ev.shape[0])
        return torch.cat([ev[:k], ev[-k:]])                        # 谱基线特征（同量级）

    # 简单线性探针（闭式最小二乘）评估可分性
    def probe_accuracy(feat_fn):
        Xs, ys = [], []
        for D0s, D1s, ms, y in samples:
            Xs.append(feat_fn(D0s, D1s, ms))
            ys.append(float(y))
        Xm = torch.stack(Xs, dim=0).numpy()
        yv = np.array(ys)
        Xm = np.concatenate([Xm, np.ones((Xm.shape[0], 1))], axis=1)
        w_np, *_ = np.linalg.lstsq(Xm, yv, rcond=None)
        pred = Xm @ w_np
        acc = float(np.mean((pred > 0.5).astype(float) == yv))
        return acc

    acc_op = probe_accuracy(op_features)
    acc_mlp = probe_accuracy(mlp_features)
    results["ablation"] = {
        "operator_layer_acc": acc_op, "mlp_baseline_acc": acc_mlp,
        "pass": bool(acc_op >= acc_mlp),
    }

    if verbose:
        print("=== 四类硬测试 ===")
        ds_str = [("-" if d["d_s"] is None else f"{d['d_s']:.3f}") for d in ds_vals]
        print(f"[1] 维度涌现: d_s = {ds_str} (n0={[d['n0'] for d in ds_vals]})"
              f"  (std={ds_std:.3e})  pass={results['dimension_emergence']['pass']}")
        print(f"[2] 先验不变性: max pairwise dist = {np.max(dists):.3e}"
              f"  pass={results['prior_invariance']['pass']}")
        print(f"[3] 跨域迁移: zero-shot 相对残差 = {transfer_res:.3e}"
              f"  pass={results['cross_domain_transfer']['pass']}")
        print(f"[4] 消融: 算子层 acc={acc_op:.3f} vs MLP 基线 acc={acc_mlp:.3f}"
              f"  pass={results['ablation']['pass']}")
    return results


# ---------------------------------------------------------------------------
# 5.5 Checkpoint 序列化（发布就绪）
# ---------------------------------------------------------------------------
def save_checkpoint(path: str, state: dict):
    """把训练好的组件打包保存为 .pt checkpoint。

    纯 tensor + raw 类型，兼容 PyTorch 2.6+ 的 weights_only 安全限制
    （numpy 数组已在内部转为 tensor，pickle 安全）。

    典型用法：``save_checkpoint(path, {"pooler": pool, "gauge": gauge,
    "head": head, "D0": D0_t, "D1": D1_t, "meta": {...}})``

    参数:
        path: str, 输出文件路径（.pt）
        state: dict, 任意组合，值可以是 nn.Module / Tensor / numpy / 标量
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    payload = {}
    for key, val in state.items():
        if isinstance(val, nn.Module):
            payload[key] = {"_type": "module",
                            "class": val.__class__.__name__,
                            "state_dict": val.state_dict()}
        elif isinstance(val, torch.Tensor):
            payload[key] = {"_type": "tensor", "value": val.detach().cpu().contiguous()}
        elif isinstance(val, np.ndarray):
            payload[key] = {"_type": "tensor",
                            "value": torch.tensor(val, dtype=torch.float64).cpu().contiguous()}
        elif isinstance(val, dict) and all(isinstance(v, torch.Tensor) for v in val.values()):
            # 直接传了 state_dict（dict of tensor），包装成 module state
            payload[key] = {"_type": "state_dict",
                            "value": {k: v.detach().cpu().contiguous() for k, v in val.items()}}
        elif isinstance(val, dict):
            # 普通 dict（可能是 config / meta），递归处理每个 value
            nested = {}
            for k2, v2 in val.items():
                nested[k2] = _serialize_val(v2)
            payload[key] = {"_type": "raw_dict", "value": nested}
        else:
            payload[key] = {"_type": "raw", "value": val}
    try:
        torch.save(payload, path, weights_only=False)
    except TypeError:
        torch.save(payload, path)                   # torch < 2.6 兼容


def _serialize_val(val):
    """辅助：把嵌套值转成 pickle-safe 形式。"""
    if isinstance(val, torch.Tensor):
        return val.detach().cpu().contiguous()
    if isinstance(val, np.ndarray):
        return torch.tensor(val, dtype=torch.float64).cpu().contiguous()
    if isinstance(val, dict):
        return {k: _serialize_val(v) for k, v in val.items()}
    if isinstance(val, (list, tuple)):
        return [_serialize_val(x) for x in val]
    return val


def load_checkpoint(path: str):
    """读入 checkpoint 并重建 nn.Module（需先在当前 namespace 中 import 类）。

    返回 dict，结构同保存时一致；nn.Module 会被正确还原。
    """
    payload = torch.load(path, map_location="cpu", weights_only=False)
    out = {}
    module_registry = {"SoftAggPooler": SoftAggPooler,
                       "ScaleGauge": ScaleGauge,
                       "LevelAttentionHead": LevelAttentionHead}
    for key, entry in payload.items():
        t = entry.get("_type")
        if t == "module":
            cls = module_registry.get(entry["class"])
            if cls is None:
                out[key] = entry["state_dict"]            # 仅返回 dict 让调用方手动加载
            else:
                raise ValueError(
                    f"Module '{entry['class']}' 需显式构建再调用 .load_state_dict()，"
                    f"由调用方决定超参数。返回裸 state_dict 以供手动加载。")
        elif t == "tensor":
            out[key] = entry["value"].to(_DTYPE)
        elif t == "numpy":
            out[key] = entry["value"]
        else:
            out[key] = entry["value"]
    return out


# ---------------------------------------------------------------------------
# 6. 自检入口
# ---------------------------------------------------------------------------
def _selfcheck_aggregate(name: str, D0, D1, m0) -> str:
    """自检：聚合后 β 严格保持且链复形合法。

    参数:
        name: str, 图名；D0, D1, m0 —— numpy 链复形与边权
    返回:
        str, 一行结果描述
    """
    D0n = _as_numpy(D0)
    n0 = D0n.shape[1]
    b = exact_beta(D0, D1)
    P = tree_partition(D0, D1)
    D0p, D1p, mp, _ = aggregate_complex(D0, D1, m0, np.ones((n0, 1)), P)
    b2 = exact_beta(D0p, D1p)
    legal = float(torch.linalg.matrix_norm(D1p @ D0p, ord="fro"))
    ok = (b == b2) and legal < 1e-12 and P.shape[1] * 2 <= n0
    return (f"{name}: n0 {n0} -> {P.shape[1]} (缩减 {n0 / P.shape[1]:.1f}×), "
            f"β {b} -> {b2}, ‖D1'D0'‖={legal:.1e}  [{'OK' if ok else 'FAIL'}]")


if __name__ == "__main__":
    print("== SRE 可微拓扑模型层自检 ==")
    _validate_environment()
    torch.manual_seed(0)
    np.random.seed(0)

    print("\n[Step 1] 承重件：粗粒化 / 池化（精确模式保 β）")
    # 裸环 C6：无 2-面 → β₁ = 1（与 test_sre_topo_model.py 同款）
    D0c = np.zeros((6, 6))
    for e, (u, v) in enumerate([(i, (i + 1) % 6) for i in range(6)]):
        D0c[e, u] = -1.0
        D0c[e, v] = 1.0
    D1c = np.zeros((0, 6))
    m0c = 0.5 + 1.5 * np.random.RandomState(3).rand(6)
    print("  " + _selfcheck_aggregate("环 C6(裸环)", D0c, D1c, m0c))

    cc = oc.ChainComplex.triangular_band(8)
    D0t, D1t = cc.D0.numpy(), cc.D1.numpy()
    m0t = 0.5 + 1.5 * np.random.RandomState(4).rand(D0t.shape[0])
    print("  " + _selfcheck_aggregate("三角带 n=8", D0t, D1t, m0t))

    D0e, D1e, _, _, m0e, _ = build_chain_complex_with_weights(
        ETHANOL_POSITIONS, ETHANOL_ATOMTYPES, bonds=ETHANOL_BONDS)
    print("  " + _selfcheck_aggregate("乙醇", D0e, D1e, m0e))

    D0r, D1r, m0r = _make_rmat_complex(n=16, edge_factor=2, seed=7)
    print("  " + _selfcheck_aggregate("随机图 n=16", D0r, D1r, m0r))

    print("  Galerkin 残差与 τ 实现一致性见 test_sre_topo_model.py")

    print("\n[Step 2] 最小可训练原型（自监督）")
    run_selfsupervised_demo(iters=1200, verbose=True)

    print("\n[Step 3/4] 四类硬测试")
    run_hard_tests(verbose=True)
