# -*- coding: utf-8 -*-
"""可微离散算子微积分 (Differentiable Discrete Operator Calculus)

本模块把 SRE 的 19 个"固定算子"提升为一个**可微的算子演算**：

骨架 (Discrete Exterior Calculus, DEC)
-------------------------------------
    d     : C^k -> C^{k+1}         外导数 (boundary 的对偶)
    delta : = d^T                  余微分 (codifferential)
    Delta : = d delta + delta d    Hodge Laplacian (块对角: L0, L1, L2)
    核心恒等式: d o d = 0

演算 (Calculus) —— 封闭的算子代数
--------------------------------
    - 组合 (composition):   A @ B
    - 交换子 (commutator):  [A, B] = A B - B A
    - 高阶迭代:             Delta^k, ad_A^k(B) = [A, ad_A^{k-1}(B)]
    - 函数演算:             f(Delta)  —— 用 Chebyshev 多项式展开实现
    以上结果**仍然是一个 Operator (N x N 矩阵)**，即演算封闭。

可微 (Differentiability)
-----------------------
    参数: 边权 w (torch tensor, requires_grad=True)
    L0(w) = D0^T diag(w) D0   —— 加权图 Laplacian (可微)
    任意标量泛函 L(w) 的梯度由 torch.autograd 给出: dL/dw

    函数演算用 **Chebyshev 多项式** 而非 eigh 特征分解:
      g(A) ~ 0.5 c0 I + sum_k c_k T_k(Y),  Y = 2A/b - I
    这样梯度只经过矩阵乘法，**天然规避了特征值简并导致的求导不稳定**。

与既有算子模块的关系
-------------------
    Op13 (Chebyshev 矩) 是本模块函数演算的一个特例;
    Op14/Op18 (Hodge / 同调) 是本模块 delta / Delta / d^2=0 的实例。
    本模块提供的是"生成器", 19 个算子是它的一张"快照"。
"""

from __future__ import annotations

import numpy as np
import torch

torch.set_default_dtype(torch.float64)
_DTYPE = torch.float64


# ---------------------------------------------------------------------------
# 1. 链复形
# ---------------------------------------------------------------------------
class ChainComplex:
    """离散链复形  C0 --d0--> C1 --d1--> C2 ,  满足 D1 @ D0 = 0。

    约定: D0[e, v] = +1 (v 为边 e 的箭头/head), -1 (tail)。
          D1[f, e] = +1 (边 e 沿其存储方向出现在面 f 的边界上), -1 (反向)。
    由此 D1 @ D0 = 0 恒成立 (边界的边界为空)。
    """

    def __init__(self, D0, D1, edge_index=None, faces=None):
        self.D0 = D0.to(_DTYPE)   # (n1, n0)
        self.D1 = D1.to(_DTYPE)   # (n2, n1)
        self.n0, self.n1, self.n2 = self.D0.shape[1], self.D0.shape[0], self.D1.shape[0]
        self.N = self.n0 + self.n1 + self.n2
        self.edge_index = edge_index
        self.faces = faces

    # ---- 构造器: 环 + 跳边 + 三角面 ----
    @staticmethod
    def triangular_band(n: int = 8) -> "ChainComplex":
        """n 个顶点的环, 加 n 条跳边(弦), 加 n 个三角面。(n >= 4)"""
        if n < 4:
            raise ValueError("triangular_band 需要 n >= 4")
        edges = [(i, (i + 1) % n) for i in range(n)]      # 环边
        edges += [(i, (i + 2) % n) for i in range(n)]     # 跳边
        edge_id = {e: i for i, e in enumerate(edges)}
        n1 = len(edges)

        D0 = torch.zeros(n1, n)
        for eid, (a, b) in enumerate(edges):
            D0[eid, b] += 1.0
            D0[eid, a] -= 1.0

        faces = [(i, (i + 1) % n, (i + 2) % n) for i in range(n)]
        D1 = torch.zeros(len(faces), n1)
        for fid, (a, b, c) in enumerate(faces):
            for s, t in ((a, b), (b, c), (c, a)):
                if (s, t) in edge_id:
                    D1[fid, edge_id[(s, t)]] += 1.0
                elif (t, s) in edge_id:
                    D1[fid, edge_id[(t, s)]] -= 1.0
                else:  # pragma: no cover - 构造上不会发生
                    raise ValueError(f"三角面需要边 ({s},{t})")
        return ChainComplex(D0, D1, edge_index=edges, faces=faces)

    def dims(self):
        return (self.n0, self.n1, self.n2)


# ---------------------------------------------------------------------------
# 2. 算子 (封闭的演算元素)
# ---------------------------------------------------------------------------
class Operator:
    """链复形 C = C0 (+) C1 (+) C2 上的一致 (N x N) 线性算子。

    组合 / 交换子 / 幂 / 函数演算 的结果**仍是 Operator**, 即演算封闭。
    """

    __array_priority__ = 1000

    def __init__(self, matrix: torch.Tensor, calculus: "OperatorCalculus" = None, name: str = ""):
        self.M = matrix
        self.calculus = calculus
        self.name = name

    # ---- 基本 ----
    @property
    def shape(self):
        return tuple(self.M.shape)

    def __matmul__(self, other: "Operator") -> "Operator":
        return Operator(self.M @ other.M, self.calculus, f"({self.name}@{other.name})")

    def compose(self, other: "Operator") -> "Operator":
        return self.__matmul__(other)

    def __add__(self, other: "Operator") -> "Operator":
        return Operator(self.M + other.M, self.calculus, f"({self.name}+{other.name})")

    def __sub__(self, other: "Operator") -> "Operator":
        return Operator(self.M - other.M, self.calculus, f"({self.name}-{other.name})")

    def scale(self, s: float) -> "Operator":
        return Operator(s * self.M, self.calculus, f"{s}*{self.name}")

    # ---- 演算 ----
    def commutator(self, other: "Operator") -> "Operator":
        """[A, B] = A B - B A  (Lie 导数/导子的原型)"""
        return Operator(self.M @ other.M - other.M @ self.M, self.calculus, f"[{self.name},{other.name}]")

    def power(self, k: int) -> "Operator":
        """A^k  (高阶迭代算子)"""
        if k < 0:
            raise ValueError("power 需要 k >= 0")
        return Operator(torch.linalg.matrix_power(self.M, k), self.calculus, f"{self.name}^{k}")

    def functional(self, g, K: int = 24) -> "Operator":
        """函数演算 g(A): 用 Chebyshev 多项式展开, 天然可微, 无 eigh 简并问题。"""
        if self.calculus is None:
            raise ValueError("functional 需要绑定 OperatorCalculus")
        return self.calculus.chebyshev_functional(self, g, K=K)

    # ---- 读数 ----
    def trace(self) -> torch.Tensor:
        return torch.trace(self.M)

    def frobenius(self) -> torch.Tensor:
        return torch.linalg.matrix_norm(self.M, ord="fro")

    def eigenvalues(self) -> np.ndarray:
        """仅供分析 (detach), 不参与求导。"""
        return torch.linalg.eigvalsh(self.M).detach().numpy()

    def to_numpy(self) -> np.ndarray:
        return self.M.detach().numpy()

    def __repr__(self):
        return f"Operator({self.name or 'unnamed'}, shape={self.shape})"


# ---------------------------------------------------------------------------
# 3. 算子微积分
# ---------------------------------------------------------------------------
class OperatorCalculus:
    """给定链复形上的可微算子演算。"""

    def __init__(self, complex_: ChainComplex):
        self.C = complex_
        self.n0, self.n1, self.n2 = complex_.dims()
        self.N = complex_.N
        self._I = torch.eye(self.N, dtype=_DTYPE)

    # ---- 块装配 ----
    def _zeros(self, r, c):
        d = (self.n0, self.n1, self.n2)
        return torch.zeros(d[r], d[c], dtype=_DTYPE)

    def _assemble(self, blocks):
        rows = [
            torch.cat([self._zeros(r, c) if blocks[r][c] is None else blocks[r][c] for c in range(3)], dim=1)
            for r in range(3)
        ]
        return torch.cat(rows, dim=0)

    # ---- 基元 ----
    def d(self) -> Operator:
        """外导数: C0 -> C1 -> C2 (块次对角)"""
        z = None
        blocks = [[z, z, z], [self.C.D0, z, z], [z, self.C.D1, z]]
        return Operator(self._assemble(blocks), self, "d")

    def delta(self) -> Operator:
        """余微分 delta = d^T"""
        return Operator(self.d().M.T, self, "delta")

    def hodge(self, w: torch.Tensor = None) -> Operator:
        """Hodge Laplacian Delta = d delta + delta d = blockdiag(L0, L1, L2)。

        当给定边权 w 时, 仅 C0 块的加权图 Laplacian 变为 L0(w) = D0^T diag(w) D0。
        """
        D0, D1 = self.C.D0, self.C.D1
        L0 = (D0.T @ D0) if w is None else (D0.T @ torch.diag(w) @ D0)
        L1 = D0 @ D0.T + D1.T @ D1
        L2 = D1 @ D1.T
        blocks = [[L0, None, None], [None, L1, None], [None, None, L2]]
        return Operator(self._assemble(blocks), self, "Delta")

    def laplacian0(self, w: torch.Tensor) -> Operator:
        """加权图 Laplacian L0(w) = D0^T diag(w) D0 (可微参数 w)。"""
        return Operator(self.C.D0.T @ torch.diag(w) @ self.C.D0, self, "L0(w)")

    # ---- 函数演算 (Chebyshev, 可微) ----
    def chebyshev_functional(self, A: Operator, g, K: int = 24, b: float = None) -> "Operator":
        """g(A) 的 Chebyshev 多项式逼近: g(A) ~ 0.5 c0 I + sum_{k>=1} c_k T_k(Y)。

        只使用矩阵乘法 -> 梯度经 autograd, 不经过特征分解 -> 规避简并不稳定。
        b: 谱上界(常量)。省略时取谱范数; 固定 b 传入时梯度严格一致 (便于有限差分校验)。
        """
        M = A.M if isinstance(A, Operator) else A
        # 谱上界 b: 取谱范数 (对一般算子也安全; 对对称 PSD 即 lambda_max)。detach -> 常量。
        if b is None:
            b = max(float(torch.linalg.matrix_norm(M, ord=2).detach()), 1e-12)
        else:
            b = float(b)
        I = torch.eye(M.shape[0], dtype=_DTYPE)

        j = torch.arange(K, dtype=_DTYPE)
        theta = torch.pi * (j + 0.5) / K
        x = torch.cos(theta)
        lam = b * (x + 1.0) / 2.0                 # 节点映射到 [0, b]
        gvals = g(lam)                             # g 作用于特征值区间
        k = torch.arange(K, dtype=_DTYPE)
        cosk = torch.cos(k[:, None] * theta[None, :])
        c = (2.0 / K) * (cosk @ gvals)             # c_k = (2/K) sum_j g lam cos(k theta)

        Y = 2.0 * M / b - I
        T_prev, T_cur = I, Y
        out = 0.5 * c[0] * I
        if K > 1:
            out = out + c[1] * T_cur
        for kk in range(2, K):
            T_next = 2.0 * Y @ T_cur - T_prev
            out = out + c[kk] * T_next
            T_prev, T_cur = T_cur, T_next
        return Operator(out, self, f"f({A.name})")

    def functional(self, A: Operator, g, K: int = 24, b: float = None) -> "Operator":
        return self.chebyshev_functional(A, g, K=K, b=b)

    # ---- 高阶导出 ----
    def ad(self, A: Operator, B: Operator, k: int) -> Operator:
        """迭代交换子 ad_A^k(B): ad^0=B, ad^{k+1}=[A, ad^k]。"""
        if k < 0:
            raise ValueError("ad 需要 k >= 0")
        cur = B
        for _ in range(k):
            cur = A.commutator(cur)
        return cur

    # ---- 可微性: 梯度 ----
    def jacobian(self, scalar_fn, params: torch.Tensor) -> torch.Tensor:
        """对任意标量泛函求 d/dw (autograd)。"""
        return torch.autograd.grad(scalar_fn(params), params, create_graph=False)[0]


# ---------------------------------------------------------------------------
# 4. 可训练 demo: 从谱观测反演边权
# ---------------------------------------------------------------------------
def run_training_demo(seed: int = 0, iters: int = 400, P: int = 16, verbose: bool = True):
    """可微演算的可训练性验证。

    真值 w* -> 观测 Y* = g(L0(w*)) @ X  (X: n0 x P 多探针)
    模型 = g(L0(w)) @ X ; 用 autograd 训练 w。

    P 个探针提供 n0*P 个约束, 需 >= 边数 m 才可辨识。
    若 dL/dw 正确且观测充分, 损失应降至近 0 且 corr(w_hat, w*) -> 1。
    """
    torch.manual_seed(seed)
    calc = OperatorCalculus(ChainComplex.triangular_band(8))
    m = calc.n1

    w_true = 0.5 + 1.5 * torch.rand(m, dtype=_DTYPE)
    X = torch.randn(calc.n0, P, dtype=_DTYPE)          # 多探针
    g = lambda t: torch.exp(-0.35 * t)              # 光滑谱滤波器

    with torch.no_grad():
        target = (calc.functional(calc.laplacian0(w_true), g, K=32).M @ X).detach()

    rho = torch.zeros(m, dtype=_DTYPE, requires_grad=True)   # w = softplus(rho) > 0
    opt = torch.optim.Adam([rho], lr=0.08)

    def loss_of(r):
        w = torch.nn.functional.softplus(r) + 1e-6
        pred = calc.functional(calc.laplacian0(w), g, K=32).M @ X
        return torch.mean((pred - target) ** 2)

    with torch.no_grad():
        loss0 = float(loss_of(rho))
    for _ in range(iters):
        opt.zero_grad()
        loss = loss_of(rho)
        loss.backward()
        opt.step()
    with torch.no_grad():
        loss1 = float(loss_of(rho))
        w_hat = (torch.nn.functional.softplus(rho) + 1e-6).numpy()
        w_rec = w_true.numpy()
        corr = float(np.corrcoef(w_hat, w_rec)[0, 1])
        mae = float(np.mean(np.abs(w_hat - w_rec)))

    if verbose:
        print(f"[demo] P={P} probes, {m} unknowns -> {calc.n0 * P} constraints")
        print(f"[demo] loss {loss0:.6e} -> {loss1:.6e}  (ratio {loss1 / max(loss0, 1e-300):.2e})")
        print(f"[demo] corr(w_hat, w*) = {corr:.4f}   MAE = {mae:.4f}")
    return {"loss0": loss0, "loss1": loss1, "corr": corr, "mae": mae,
            "w_hat": w_hat, "w_true": w_true.numpy()}


if __name__ == "__main__":
    torch.manual_seed(0)
    cc = ChainComplex.triangular_band(8)
    calc = OperatorCalculus(cc)
    d, delta, L = calc.d(), calc.delta(), calc.hodge()

    print("== 可微离散算子微积分 (Differentiable Discrete Operator Calculus) ==")
    print(f"链复形: C0={cc.n0}, C1={cc.n1}, C2={cc.n2}   总维 N={cc.N}")
    print(f"d1∘d0 = 0     : {float(torch.linalg.matrix_norm(cc.D1 @ cc.D0, ord='fro')):.2e}")
    print(f"d∘d   = 0     : {float(torch.linalg.matrix_norm(d.M @ d.M, ord='fro')):.2e}")
    print(f"delta = d^T   : {float(torch.linalg.matrix_norm(delta.M - d.M.T, ord='fro')):.2e}")
    print(f"Delta=dδ+δd   : {float(torch.linalg.matrix_norm(L.M - ((d @ delta).M + (delta @ d).M), ord='fro')):.2e}")
    print(f"Delta 对称    : {float(torch.linalg.matrix_norm(L.M - L.M.T, ord='fro')):.2e}")
    lam = torch.linalg.eigvalsh(L.M)
    print(f"Delta PSD     : λmin={float(lam.min()):.3e}, λmax={float(lam.max()):.3e}")
    print()
    print("[演算] 组合/交换子/高阶 —— 结果仍是算子 (封闭)")
    print(f"  [d, delta] Frobenius = {float(d.commutator(delta).frobenius()):.3e}")
    print(f"  ad_d^2(delta).shape  = {calc.ad(d, delta, 2).shape}")
    print(f"  Delta^3 trace        = {float(L.power(3).trace()):.3e}")
    print()
    print("[函数演算] Chebyshev 多项式展开 (无 eigh, 可微, 免简并)")
    g = lambda t: torch.exp(-0.35 * t)
    L0 = calc.laplacian0(0.5 + 1.5 * torch.rand(cc.n1, dtype=_DTYPE))
    approx = calc.functional(L0, g, K=48).M
    lamv, V = torch.linalg.eigh(L0.M)
    exact = (V * g(lamv)) @ V.T
    print(f"  ||Chebyshev - eigh|| = {float(torch.linalg.matrix_norm(approx - exact, ord='fro')):.3e}")
    print()
    run_training_demo()
