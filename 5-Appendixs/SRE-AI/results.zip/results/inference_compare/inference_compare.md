# 补充实验5: 推理模式对照 (松弛 vs 原生离散)

同一训练权重, 仅切换推理模式 (force_mode=Training vs Inference)

- **松弛推理 (A)**: SREMode::Training, 连续松弛 χ=sigmoid, soft-sign=tanh
- **离散推理 (B)**: SREMode::Inference, 原生 {±1} 自旋, 硬 sgn, 布尔 χ
- **ΔAUC = AUC(B) - AUC(A)**: 量化从松弛切换到原生离散的性能衰减

| 数据集 | 模型 | AUC(松弛) | AUC(离散) | ΔAUC | F1(松弛) | F1(离散) | ΔF1 |
|---|---|---|---|---|---|---|---|
| ogb_mol_depth2 | sre_ai_soft | 0.7676 | 0.7724 | +0.0048 | 0.0000 | 0.0000 | +0.0000 |
| ogb_mol_depth2 | sre_ai_hard | 0.7594 | 0.7638 | +0.0044 | 0.0000 | 0.0000 | +0.0000 |
| ogb_mol_depth4 | sre_ai_soft | 0.7997 | 0.8025 | +0.0028 | 0.0000 | 0.0000 | +0.0000 |
| ogb_mol_depth4 | sre_ai_hard | 0.7818 | 0.7849 | +0.0031 | 0.0000 | 0.0000 | +0.0000 |
| ogb_mol_depth8 | sre_ai_soft | 0.7462 | 0.7257 | -0.0205 | 0.0000 | 0.0000 | +0.0000 |
| ogb_mol_depth8 | sre_ai_hard | 0.7991 | 0.7981 | -0.0010 | 0.0000 | 0.0000 | +0.0000 |
| elliptic | sre_ai_soft | 0.9971 | 0.9892 | -0.0079 | 0.9107 | 0.8189 | -0.0918 |
| elliptic | sre_ai_hard | 0.9972 | 0.9894 | -0.0078 | 0.9107 | 0.8189 | -0.0918 |